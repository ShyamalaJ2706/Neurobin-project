
import React from 'react';

interface GmailSimulationProps {
  username: string;
  email: string;
  onComplete: () => void;
}

export const GmailSimulation: React.FC<GmailSimulationProps> = ({ username, email, onComplete }) => {
  const emails = [
    {
      sender: 'noreply@gmail.com',
      subject: 'Welcome to Neuro Bin Enterprise Hub',
      snippet: `Confirmed: Successful registration for ${username}. No internal verification is needed on the app...`,
      time: 'Just now',
      color: 'bg-emerald-600',
      icon: 'fa-recycle',
      unread: true
    },
    {
      sender: 'Google Workspace',
      subject: 'New device signed in to your account',
      snippet: 'Your account was used to sign in to a new device...',
      time: '2 mins ago',
      color: 'bg-slate-700',
      icon: 'fa-brands fa-google',
      unread: false
    },
    {
      sender: 'LinkedIn',
      subject: 'Neuro Bin and 5 others shared posts',
      snippet: 'Regional waste management trends for 2025...',
      time: '1 hour ago',
      color: 'bg-blue-600',
      icon: 'fa-brands fa-linkedin-in',
      unread: false
    }
  ];

  return (
    <div className="fixed inset-0 z-[99999] bg-[#121212] font-sans flex flex-col animate-fade-in">
      {/* Top Search Bar */}
      <div className="p-4 pt-10">
        <div className="bg-[#2d2e30] rounded-full h-14 flex items-center px-6 gap-4 shadow-lg border border-white/5">
          <i className="fa-solid fa-bars text-slate-400"></i>
          <span className="flex-1 text-slate-400 text-sm font-medium">Search in emails</span>
          <div className="w-8 h-8 rounded-full bg-emerald-600 flex items-center justify-center text-white text-[10px] font-black">
            {username[0].toUpperCase()}
          </div>
        </div>
      </div>

      <div className="px-6 py-2">
         <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Inbox</span>
      </div>

      {/* Email List */}
      <div className="flex-1 overflow-y-auto pb-24">
        {emails.map((e, i) => (
          <div key={i} className="px-6 py-4 flex gap-5 items-start hover:bg-white/5 transition-colors cursor-pointer relative">
            <div className={`w-12 h-12 rounded-full ${e.color} flex items-center justify-center text-white text-lg shrink-0`}>
              <i className={`fa-solid ${e.icon}`}></i>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex justify-between items-center mb-0.5">
                <h4 className={`text-[15px] ${e.unread ? 'text-white font-black' : 'text-slate-300 font-medium'} truncate`}>
                  {e.sender}
                </h4>
                <div className="flex items-center gap-2">
                   <span className={`text-[11px] ${e.unread ? 'text-white font-black' : 'text-slate-500 font-medium'}`}>{e.time}</span>
                   {e.unread && <div className="w-2 h-2 rounded-full bg-blue-500"></div>}
                </div>
              </div>
              <p className={`text-[13px] ${e.unread ? 'text-white font-black' : 'text-slate-400 font-medium'} truncate mb-0.5`}>
                {e.subject}
              </p>
              <div className="flex justify-between items-center gap-2">
                 <p className="text-[13px] text-slate-500 font-medium truncate flex-1">{e.snippet}</p>
                 <i className="fa-regular fa-star text-slate-500 text-sm"></i>
              </div>
            </div>
            {i === 0 && (
              <div className="absolute left-0 top-0 bottom-0 w-1 bg-blue-500"></div>
            )}
          </div>
        ))}
      </div>

      {/* Floating Action Button */}
      <div className="fixed bottom-10 right-8">
         <div className="bg-[#c2e7ff] h-16 px-6 rounded-2xl flex items-center gap-4 shadow-2xl hover:scale-105 active:scale-95 transition-all text-[#001d35]">
            <i className="fa-solid fa-pencil text-xl"></i>
            <span className="text-sm font-black">Compose</span>
         </div>
      </div>

      {/* Entry Overlay */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-full max-w-xs flex flex-col gap-4">
          <div className="bg-slate-900 border border-white/10 p-4 rounded-2xl shadow-2xl text-center">
            <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest italic mb-2">Registration Status</p>
            <p className="text-emerald-500 text-xs font-black uppercase italic">Handshake Successful</p>
          </div>
          <button 
            onClick={onComplete}
            className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-4xl hover:bg-emerald-500 transition-all animate-bounce"
          >
            Launch Command Hub
          </button>
      </div>

      {/* Navigation Simulation */}
      <div className="bg-[#1e1e1e] h-20 border-t border-white/5 flex items-center justify-around px-10">
          <div className="flex flex-col items-center gap-1 text-[#c2e7ff]">
              <i className="fa-solid fa-envelope text-xl"></i>
              <span className="text-[10px] font-bold">Mail</span>
          </div>
          <div className="flex flex-col items-center gap-1 text-slate-500">
              <i className="fa-solid fa-video text-xl"></i>
              <span className="text-[10px] font-bold">Meet</span>
          </div>
      </div>
    </div>
  );
};
