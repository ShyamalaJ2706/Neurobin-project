
import React from 'react';
import { Logo } from './Logo';

interface LandingPageProps {
  onSelectMode: (mode: 'citizen' | 'staff') => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onSelectMode }) => {
  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 relative overflow-hidden font-sans text-center">
      {/* Background Decor */}
      <div className="absolute top-[-10%] left-[-10%] w-[600px] h-[600px] bg-brand-500/5 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] bg-indigo-500/5 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="max-w-5xl w-full grid grid-cols-1 lg:grid-cols-2 gap-12 z-10 items-center">
        {/* Branding Section */}
        <div className="flex flex-col justify-center text-center lg:text-left space-y-8 p-4">
          <div className="w-32 h-32 bg-white border border-brand-200 rounded-[2.5rem] flex items-center justify-center shadow-2xl mb-6 mx-auto lg:mx-0 animate-float p-3">
            <Logo className="w-24 h-24" />
          </div>
          <div>
            <h1 className="text-7xl font-black text-brand-900 uppercase italic tracking-tighter leading-none mb-4">
              Neuro Bin
            </h1>
            <p className="text-brand-500 font-black text-[10px] uppercase tracking-[0.6em] mb-8 italic">
              Enterprise IoT Ecosystem
            </p>
            <p className="text-slate-500 text-lg max-w-md leading-relaxed font-medium mx-auto lg:mx-0">
              Scalable waste detection infrastructure for smart municipal regions. Leveraging real-time telemetry and advanced neural signals.
            </p>
          </div>
        </div>

        {/* Action Cards */}
        <div className="grid grid-cols-1 gap-6">
          {/* Public Portal Card */}
          <button 
            onClick={() => onSelectMode('citizen')}
            className="group bg-white border border-slate-200 hover:border-brand-500 p-10 rounded-[3rem] text-left transition-all duration-500 hover:shadow-xl relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-100 transition-opacity">
               <i className="fa-solid fa-arrow-right text-4xl text-brand-500 transform -rotate-45 group-hover:rotate-0 transition-transform duration-500"></i>
            </div>
            <div className="w-16 h-16 bg-brand-50 rounded-2xl flex items-center justify-center text-brand-600 text-2xl mb-8 group-hover:bg-brand-500 group-hover:text-white transition-all duration-500 shadow-sm border border-brand-100">
               <i className="fa-solid fa-radar"></i>
            </div>
            <h3 className="text-3xl font-black text-brand-900 uppercase italic tracking-tighter mb-4">Public View</h3>
            <p className="text-slate-400 text-sm leading-relaxed max-w-[280px] font-bold uppercase tracking-tight">
              Public interface for real-time load assessment, regional node lookup, and feedback transmission.
            </p>
          </button>

          {/* Staff Login Card */}
          <button 
            onClick={() => onSelectMode('staff')}
            className="group bg-white border border-slate-200 hover:border-brand-900 p-10 rounded-[3rem] text-left transition-all duration-500 hover:shadow-xl relative overflow-hidden"
          >
             <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-100 transition-opacity">
               <i className="fa-solid fa-arrow-right text-4xl text-brand-900 transform -rotate-45 group-hover:rotate-0 transition-transform duration-500"></i>
            </div>
            <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-600 text-2xl mb-8 group-hover:bg-brand-900 group-hover:text-white transition-all duration-500 shadow-sm border border-slate-100">
               <i className="fa-solid fa-tower-observation"></i>
            </div>
            <h3 className="text-3xl font-black text-brand-900 uppercase italic tracking-tighter mb-4">Command Center</h3>
            <p className="text-slate-400 text-sm leading-relaxed max-w-[280px] font-bold uppercase tracking-tight">
              Operational dashboard for fleet logistics and regional sector management.
            </p>
          </button>
        </div>
      </div>

      <div className="mt-20 text-center opacity-30">
        <p className="text-[9px] font-black text-slate-400 uppercase tracking-[1em] italic">
          Neuro_Core Infrastructure Systems
        </p>
      </div>
    </div>
  );
};
