
import React, { useMemo, useState, useEffect } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';
import { Bin, CitizenReport, User } from '../types';
import { DISTRICTS } from '../constants';
import { simulateHardwarePacket, subscribeToRawTelemetry } from '../services/firebaseService';

interface AnalyticsHubProps {
  bins: Bin[];
  reports: CitizenReport[];
  currentUser?: User | null;
  onLocateHardware?: (coords: { lat: number, lng: number }) => void;
}

export const AnalyticsHub: React.FC<AnalyticsHubProps> = ({ bins, reports, currentUser, onLocateHardware }) => {
  const [testLoading, setTestLoading] = useState(false);
  const [testStatus, setTestStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [rawPacket, setRawPacket] = useState<any>(null);
  const [simValues, setSimValues] = useState({ b1: 150, b2: 120 });

  useEffect(() => {
    const unsub = subscribeToRawTelemetry((data) => setRawPacket(data));
    return () => unsub();
  }, []);

  const districtData = useMemo(() => {
    return DISTRICTS.map(district => {
      const districtBins = bins.filter(b => b.district === district);
      const avgFill = districtBins.length 
        ? Math.round(districtBins.reduce((acc, b) => acc + b.fillLevel, 0) / districtBins.length)
        : 0;
      return { name: district, fill: avgFill };
    });
  }, [bins]);

  const handleManualSim = async () => {
    setTestLoading(true);
    await simulateHardwarePacket(simValues.b1, simValues.b2);
    setTestStatus('success');
    setTimeout(() => {
        setTestStatus('idle');
        setTestLoading(false);
    }, 1500);
  };

  return (
    <div className="space-y-3 animate-fade-in max-w-5xl mx-auto pb-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-lg font-bold text-brand-900">Diagnostic Hub</h2>
          <p className="text-brand-500 text-[9px] font-medium mt-0.5">Real-time system health and hardware telemetry</p>
        </div>
        <div className="bg-white border border-brand-200 px-2 py-1 rounded-lg flex items-center gap-2 shadow-sm">
          <span className={`w-1 h-1 rounded-full ${rawPacket ? 'bg-brand-500' : 'bg-brand-300'}`}></span>
          <span className="text-[7px] font-bold uppercase tracking-wider text-brand-600">{rawPacket ? 'Uplink Live' : 'No Signal'}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {/* Terminal Card */}
        <div className="bg-brand-900 p-3 rounded-xl shadow-lg h-[250px] flex flex-col">
           <div className="flex justify-between items-center mb-3">
              <span className="text-[7px] font-bold text-brand-400 uppercase tracking-widest">Telemetry Stream</span>
              <span className="text-brand-600 font-mono text-[7px]">v4.2</span>
           </div>
           <div className="flex-1 overflow-y-auto custom-scroll font-mono text-xs">
              {rawPacket ? (
                <div className="space-y-2">
                  <pre className="text-brand-200 text-[9px]">
                     {`// Packet @ ${new Date().toLocaleTimeString()}\n`}
                     {JSON.stringify(rawPacket, null, 2)}
                  </pre>
                  
                  {(rawPacket.lat || rawPacket.latitude) && (
                    <div className="bg-brand-800/50 p-2 rounded-lg border border-brand-700/50 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-5 h-5 bg-brand-500 rounded flex items-center justify-center text-white text-[9px]">
                          <i className="fa-solid fa-location-dot"></i>
                        </div>
                        <div>
                          <p className="text-[5px] text-brand-400 uppercase tracking-widest leading-none mb-0.5">Hardware Fix</p>
                          <p className="text-[9px] text-brand-100 font-bold">
                            {Number(rawPacket.lat || rawPacket.latitude).toFixed(6)}, {Number(rawPacket.lng || rawPacket.longitude).toFixed(6)}
                          </p>
                        </div>
                      </div>
                      <button 
                        onClick={() => onLocateHardware?.({ 
                          lat: parseFloat(rawPacket.lat || rawPacket.latitude), 
                          lng: parseFloat(rawPacket.lng || rawPacket.longitude) 
                        })}
                        className="bg-brand-500 hover:bg-brand-400 text-white px-2 py-1 rounded text-[7px] font-bold uppercase tracking-wider transition-all"
                      >
                        View on Map
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-brand-700 space-y-1.5">
                    <i className="fa-solid fa-satellite-dish text-xl opacity-20"></i>
                    <p className="text-[7px] font-bold uppercase tracking-widest">Listening for data...</p>
                </div>
              )}
           </div>
        </div>

        {/* Control Card */}
        <div className="bg-white border border-brand-200 p-3 rounded-xl shadow-sm flex flex-col gap-3">
            <div>
              <h3 className="text-sm font-bold text-brand-900 mb-0.5">Hardware Emulator</h3>
              <p className="text-[9px] text-brand-400 font-medium">Test system responsiveness under specific loads</p>
            </div>
            
            <div className="space-y-3">
               <div className="space-y-1.5">
                  <div className="flex justify-between text-[7px] font-bold uppercase text-brand-500">
                     <span>Node Alpha-1</span>
                     <span>{simValues.b1}cm</span>
                  </div>
                  <input 
                    type="range" min="0" max="200" value={simValues.b1} 
                    onChange={(e) => setSimValues({...simValues, b1: parseInt(e.target.value)})}
                    className="w-full accent-brand-500 h-1 bg-brand-100 rounded-full"
                  />
               </div>
               <div className="space-y-1.5">
                  <div className="flex justify-between text-[7px] font-bold uppercase text-brand-500">
                     <span>Node Beta-1</span>
                     <span>{simValues.b2}cm</span>
                  </div>
                  <input 
                    type="range" min="0" max="200" value={simValues.b2} 
                    onChange={(e) => setSimValues({...simValues, b2: parseInt(e.target.value)})}
                    className="w-full accent-brand-500 h-1 bg-brand-100 rounded-full"
                  />
               </div>
            </div>

            <button 
              onClick={handleManualSim}
              disabled={testLoading}
              className={`w-full py-2 rounded-lg text-[9px] font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${testStatus === 'success' ? 'bg-green-500 text-white' : 'bg-brand-900 text-white hover:bg-brand-800'}`}
            >
              {testLoading ? 'Broadcasting...' : testStatus === 'success' ? 'Packet Sent' : 'Emit Test Pulse'}
              {testStatus === 'success' && <i className="fa-solid fa-check text-[9px]"></i>}
            </button>
        </div>
      </div>

      <div className="bg-white border border-brand-200 p-3 rounded-xl shadow-sm h-[200px] flex flex-col">
          <h3 className="text-[9px] font-bold uppercase tracking-widest text-brand-400 mb-2">Regional Load Distribution</h3>
          <div className="flex-1 w-full min-h-0">
            <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
              <BarChart data={districtData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={7} fontWeight="bold" />
                <YAxis stroke="#94a3b8" fontSize={7} fontWeight="bold" unit="%" />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }} 
                  contentStyle={{ borderRadius: '6px', border: 'none', background: '#0F172A', color: '#fff', fontSize: '7px' }} 
                />
                <Bar dataKey="fill" fill="#2563EB" radius={[3, 3, 0, 0]} barSize={25} />
              </BarChart>
            </ResponsiveContainer>
          </div>
      </div>
    </div>
  );
};
