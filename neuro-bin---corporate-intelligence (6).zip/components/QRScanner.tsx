
import React, { useState, useEffect, useRef } from 'react';
import { Bin } from '../types';

interface IdentifyUnitProps {
  bins: Bin[];
  onScan: (binId: string) => void;
  onClose: () => void;
}

export const QRScanner: React.FC<IdentifyUnitProps> = ({ bins, onScan, onClose }) => {
  const [error, setError] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [manualId, setManualId] = useState('');
  const [showManual, setShowManual] = useState(false);
  const [scanStatus, setScanStatus] = useState('Optical Sensor: Offline');
  const [flash, setFlash] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const scannerRef = useRef<any>(null);

  const initScanner = async () => {
    setError(null);
    setScanStatus('Initializing Lens...');
    setIsCameraActive(true);
    
    try {
      console.log("Initializing scanner...");
      await new Promise(r => setTimeout(r, 600)); // Buffer for DOM stability
      
      if (!(window as any).Html5Qrcode) {
        console.error("Html5Qrcode not found on window");
        throw new Error("Optical engine runtime not found. Check your internet connection.");
      }

      if (!scannerRef.current) {
        console.log("Creating new Html5Qrcode instance");
        scannerRef.current = new (window as any).Html5Qrcode("qr-reader-target");
      }

      const config = {
        fps: 20,
        qrbox: (width: number, height: number) => {
          const size = Math.min(width, height) * 0.75;
          return { width: size, height: size };
        },
        aspectRatio: 1.0,
      };

      console.log("Starting scanner...");
      await scannerRef.current.start(
        { facingMode: "environment" },
        config,
        (decodedText: string) => {
          console.log("QR Detected:", decodedText);
          if (!isAnalyzing) {
            handleDetected(decodedText);
          }
        },
        (errorMessage: string) => {
          // Frame skip - too noisy to log
        }
      );
      
      setScanStatus('Scanning Municipal Tags...');
    } catch (err: any) {
      console.error("Scanner Link Error:", err);
      setIsCameraActive(false);
      setError(`Hardware Sync Failed: ${err.message || "Ensure camera permissions are granted."}`);
    }
  };

  const handleDetected = (text: string) => {
    setFlash(true);
    setIsAnalyzing(true);
    setScanStatus('Registry Signature Found');

    if (window.navigator.vibrate) window.navigator.vibrate([100, 50, 100]);

    // Robust Extraction: Pull BIN-XXXX even from complex URLs
    let finalId = text.trim();
    
    // Check for the specific survey link or any URL
    if (finalId.includes('docs.google.com/forms') || finalId.startsWith('http')) {
      setScanStatus('External Link Detected');
      setTimeout(() => {
        if (window.confirm("Establish external link to survey?")) {
          window.open(finalId, '_blank');
        }
        onClose();
      }, 800);
      return;
    }

    const idRegex = /BIN-\d{4}/i;
    const match = text.match(idRegex);
    if (match) {
      finalId = match[0].toUpperCase();
    }

    setTimeout(() => {
      onScan(finalId);
    }, 800);
  };

  useEffect(() => {
    return () => {
      if (scannerRef.current && scannerRef.current.isScanning) {
        scannerRef.current.stop().catch(() => {});
      }
    };
  }, []);

  return (
    <div className="fixed inset-0 bg-slate-950 z-[99999] flex flex-col font-sans overflow-hidden animate-fade-in">
      <div className="p-8 flex items-center justify-between z-50 bg-slate-900 border-b border-white/5 shadow-2xl">
        <div className="flex items-center gap-6">
          <div className="w-12 h-12 bg-brand-600 rounded-2xl flex items-center justify-center text-white text-xl shadow-lg">
            <i className="fa-solid fa-expand"></i>
          </div>
          <div>
            <h2 className="text-[10px] font-black uppercase tracking-[0.5em] text-white italic">Neural Link v4.2</h2>
            <p className="text-[9px] font-bold text-brand-400 uppercase tracking-[0.2em] mt-1 animate-pulse">{scanStatus}</p>
          </div>
        </div>
        <button onClick={onClose} className="w-12 h-12 rounded-2xl bg-white/5 text-white flex items-center justify-center hover:bg-brand-500/20 transition-all border border-white/5">
          <i className="fa-solid fa-xmark text-xl"></i>
        </button>
      </div>

      <div className="relative flex-1 w-full bg-black flex items-center justify-center overflow-hidden">
        <div id="qr-reader-target" className="absolute inset-0 w-full h-full opacity-70"></div>

        {!isCameraActive && !error && (
          <div className="absolute inset-0 z-50 flex flex-col items-center justify-center p-12 text-center bg-slate-950/90 backdrop-blur-xl">
            <div className="w-24 h-24 bg-brand-600/10 text-brand-400 rounded-[2.5rem] flex items-center justify-center text-4xl mb-10 border border-brand-500/20 shadow-4xl animate-float">
              <i className="fa-solid fa-camera"></i>
            </div>
            <h3 className="text-3xl font-black text-white uppercase italic tracking-tighter mb-4 leading-none">Optical Handshake Required</h3>
            <p className="text-slate-500 text-sm mb-12 max-w-sm leading-relaxed font-bold uppercase tracking-widest">Establish a secure visual link with the municipal asset tag.</p>
            <button 
              onClick={initScanner}
              className="px-16 py-7 bg-brand-600 text-white rounded-[2.5rem] font-black uppercase tracking-[0.3em] text-xs shadow-4xl shadow-brand-600/30 active:scale-95 transition-all flex items-center gap-4"
            >
              <i className="fa-solid fa-bolt-lightning"></i>
              Initialize Sensor
            </button>
          </div>
        )}

        {isCameraActive && !isAnalyzing && !error && (
          <div className="absolute inset-0 pointer-events-none z-50 flex flex-col items-center justify-center">
            <div className="relative w-72 h-72 sm:w-80 sm:h-80">
              <div className="absolute top-0 left-0 w-16 h-16 border-t-[6px] border-l-[6px] border-brand-500 rounded-tl-3xl"></div>
              <div className="absolute top-0 right-0 w-16 h-16 border-t-[6px] border-r-[6px] border-brand-500 rounded-tr-3xl"></div>
              <div className="absolute bottom-0 left-0 w-16 h-16 border-b-[6px] border-l-[6px] border-brand-500 rounded-bl-3xl"></div>
              <div className="absolute bottom-0 right-0 w-16 h-16 border-b-[6px] border-r-[6px] border-brand-500 rounded-br-3xl"></div>
              <div className="absolute inset-x-0 h-1.5 bg-brand-400 shadow-[0_0_25px_#8b5cf6] animate-laser"></div>
            </div>
            <p className="mt-16 text-[10px] font-black uppercase tracking-[0.6em] text-white/50 bg-black/40 px-8 py-3 rounded-full border border-white/5 backdrop-blur-md">Target Asset Identifier</p>
          </div>
        )}

        {error && (
          <div className="absolute inset-0 z-50 flex flex-col items-center justify-center p-12 text-center bg-slate-950">
            <div className="w-20 h-20 bg-red-500/20 text-red-500 rounded-3xl flex items-center justify-center text-3xl mb-10 border border-red-500/20">
              <i className="fa-solid fa-triangle-exclamation"></i>
            </div>
            <h3 className="text-2xl font-black text-white uppercase mb-4 tracking-tighter italic">Link Failure</h3>
            <p className="text-slate-500 text-sm mb-12 max-w-sm leading-relaxed font-bold">{error}</p>
            <div className="flex flex-col gap-4 w-full max-w-xs">
              <button onClick={initScanner} className="py-6 bg-brand-600 text-white rounded-[2rem] font-black uppercase text-[11px] tracking-widest shadow-2xl">Re-attempt Sync</button>
              <button onClick={() => setShowManual(true)} className="py-6 bg-white/5 text-slate-400 rounded-[2rem] font-black uppercase text-[11px] tracking-widest border border-white/5">Manual Entry</button>
            </div>
          </div>
        )}

        {isAnalyzing && (
          <div className="absolute inset-0 bg-slate-900/95 backdrop-blur-3xl z-[100] flex flex-col items-center justify-center">
             <div className="w-24 h-24 border-4 border-brand-500/20 border-t-brand-500 rounded-full animate-spin mb-10"></div>
             <p className="text-[12px] font-black text-white uppercase tracking-[0.8em] italic">Decoding Registry...</p>
          </div>
        )}
      </div>

      {showManual && (
        <div className="absolute inset-0 bg-slate-950/98 backdrop-blur-3xl z-[200] flex items-center justify-center p-10 animate-fade-in">
          <div className="bg-slate-900 border border-white/10 rounded-[4rem] p-16 w-full max-w-lg shadow-4xl text-center">
            <h3 className="text-slate-500 font-black uppercase tracking-[0.5em] text-[10px] mb-12 italic">Tactical Override</h3>
            <input 
              type="text" 
              value={manualId}
              onChange={(e) => setManualId(e.target.value)}
              placeholder="e.g. BIN-1024 or https://..."
              className="w-full bg-black border border-white/10 rounded-[2.5rem] p-10 text-white text-center font-mono text-4xl tracking-widest uppercase focus:border-brand-500 outline-none mb-12"
              autoFocus
            />
            <div className="grid grid-cols-2 gap-6">
              <button onClick={() => setShowManual(false)} className="py-6 text-slate-600 font-black uppercase text-[11px] tracking-widest">Abort</button>
              <button onClick={() => handleDetected(manualId)} className="py-6 bg-brand-600 rounded-[2rem] text-white font-black uppercase text-[11px] tracking-widest shadow-xl">Engage</button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes laser { 0% { top: 0; } 100% { top: 100%; } }
        .animate-laser { animation: laser 2.5s cubic-bezier(0.4, 0, 0.2, 1) infinite; }
        #qr-reader-target video { width: 100% !important; height: 100% !important; object-fit: cover !important; border-radius: 0 !important; }
      `}</style>
    </div>
  );
};
