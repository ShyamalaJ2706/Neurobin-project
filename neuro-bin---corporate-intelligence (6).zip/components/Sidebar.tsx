
import React from 'react';
import { User } from '../types';
import { Logo } from './Logo';

interface SidebarProps {
  currentView: string;
  setView: (view: 'dashboard' | 'map' | 'bins' | 'fleet' | 'analytics' | 'report') => void;
  user: User;
  onLogout: () => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  onOpenScanner: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, setView, user, onLogout, isOpen, setIsOpen, onOpenScanner }) => {
  const menuItems = [
    { id: 'dashboard', icon: 'fa-house', label: 'Dashboard' },
    { id: 'map', icon: 'fa-location-dot', label: 'Logistics Map' },
    { id: 'bins', icon: 'fa-table-list', label: 'Unit Registry' },
    { id: 'fleet', icon: 'fa-truck-moving', label: 'Fleet Systems' },
    { id: 'analytics', icon: 'fa-chart-simple', label: 'Diagnostics' },
    { id: 'report', icon: 'fa-bell', label: 'Incidents' },
  ];

  return (
    <aside className={`${isOpen ? 'w-64' : 'w-20'} bg-white h-screen flex flex-col shrink-0 z-50 border-r border-brand-200 transition-all duration-300 ease-out shadow-sm relative`}>
      {/* Header Area */}
      <div className={`p-4 border-b border-brand-50 flex flex-col items-center`}>
        <button 
          onClick={() => setIsOpen(!isOpen)} 
          className="w-12 h-12 rounded-2xl bg-brand-50 hover:bg-brand-100 flex items-center justify-center text-brand-900 mb-6 transition-colors shadow-inner"
        >
          <i className={`fa-solid ${isOpen ? 'fa-bars-staggered' : 'fa-bars'}`}></i>
        </button>
        
        {isOpen && (
          <div className="flex items-center gap-3 animate-fade-in mb-2 w-full px-2">
            <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center shadow-md border border-brand-100 p-1">
              <Logo className="w-full h-full" />
            </div>
            <div className="text-left">
              <h1 className="text-[10px] font-black text-brand-900 tracking-tight leading-none uppercase italic">Neuro Bin</h1>
              <p className="text-[7px] font-bold text-brand-400 uppercase tracking-widest mt-0.5">Regional Ops</p>
            </div>
          </div>
        )}
      </div>

      {/* Menu Area */}
      <div className="flex-1 overflow-y-auto custom-scroll p-3 py-6">
        <nav className="space-y-1.5">
          {menuItems.map((item) => {
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setView(item.id as any)}
                title={!isOpen ? item.label : ''}
                className={`w-full flex items-center ${isOpen ? 'px-4 py-3 gap-4' : 'justify-center py-4'} rounded-2xl transition-all ${
                  isActive 
                    ? 'bg-brand-900 text-white shadow-xl' 
                    : 'text-brand-400 hover:bg-brand-50 hover:text-brand-900'
                }`}
              >
                <div className="w-5 h-5 flex items-center justify-center">
                  <i className={`fa-solid ${item.icon} ${isOpen ? 'text-[11px]' : 'text-base'}`}></i>
                </div>
                {isOpen && (
                  <span className="text-[9px] font-black uppercase tracking-[0.2em] truncate animate-fade-in italic">{item.label}</span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* User Footer Area */}
      <div className={`p-4 border-t border-brand-50 bg-brand-50/10 ${isOpen ? '' : 'flex flex-col items-center'}`}>
        {isOpen ? (
          <div className="bg-white p-3 rounded-2xl border border-brand-200 shadow-sm mb-4 flex items-center gap-3 animate-fade-in">
             <div className="w-8 h-8 rounded-xl bg-brand-900 flex items-center justify-center text-white font-black text-[10px]">
               {user.username[0].toUpperCase()}
             </div>
             <div className="flex-1 min-w-0 text-left">
               <p className="text-[9px] font-black text-brand-900 truncate uppercase italic tracking-tighter leading-none">{user.username}</p>
               <p className="text-[7px] text-brand-400 font-bold uppercase tracking-widest mt-1">Authorized</p>
             </div>
          </div>
        ) : (
          <div className="w-10 h-10 rounded-xl bg-brand-900 flex items-center justify-center text-white font-black text-xs mb-4 shadow-lg border border-white/10">
             {user.username[0].toUpperCase()}
          </div>
        )}
        
        <button 
          onClick={onLogout}
          className={`w-full ${isOpen ? 'py-3.5 px-4 italic' : 'h-12 w-12'} bg-white hover:bg-rose-50 hover:text-rose-600 text-brand-400 rounded-2xl text-[8px] font-black uppercase tracking-[0.2em] transition-all border border-brand-200 flex items-center justify-center gap-2 shadow-sm`}
          title="Logout"
        >
          <i className="fa-solid fa-power-off text-[11px]"></i>
          {isOpen && <span>Sign Out</span>}
        </button>
      </div>
    </aside>
  );
};
