
import React, { useState } from 'react';
import { User } from '../types';
import { loginUser, signupUser, resetPassword } from '../services/firebaseService';
import { Logo } from './Logo';

interface LoginPageProps {
  onLogin: (user: User) => void;
  onRegister: (user: User) => void;
  defaultRole?: User['role'];
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin, onRegister, defaultRole = 'admin' as User['role'] }) => {
  const [viewState, setViewState] = useState<'login' | 'register' | 'forgot'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);

  const startResendTimer = () => {
    setResendTimer(60);
    const interval = setInterval(() => {
      setResendTimer((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');
    try {
      if (viewState === 'login') {
        const user = await loginUser(email, password);
        if (user) {
          localStorage.setItem('neuro_current_user', JSON.stringify(user));
          onLogin(user);
        }
      } else if (viewState === 'register') {
        const newUser: User = { 
          username: email.split('@')[0], 
          password, 
          role: defaultRole, 
          assignedDistrict: 'ALL', 
          email: email.toLowerCase().trim() 
        };
        await signupUser(newUser);
        localStorage.setItem('neuro_current_user', JSON.stringify(newUser));
        onRegister(newUser);
      } else {
        await resetPassword(email);
        setSuccess('Password reset link sent! Please check your inbox (and spam folder).');
        startResendTimer();
      }
    } catch (err: any) {
      console.error("Auth Error Detail:", err);
      // Provide more context for specific Firebase errors
      if (err.message.includes('not registered')) {
        setError("This email is not registered. Please create an account first.");
        setTimeout(() => setViewState('register'), 3000);
      } else if (err.message.includes('auth/user-not-found')) {
        setError("Account not found. Did you register with this exact email?");
      } else if (err.message.includes('auth/wrong-password') || err.message.includes('auth/invalid-credential')) {
        setError("Incorrect password. If you forgot it, please use the 'Forgot Password' link below.");
      } else {
        setError(err.message);
      }
    } finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen bg-brand-100/50 flex items-center justify-center p-6 font-sans">
      <div className="max-w-md w-full bg-white rounded-[3rem] shadow-2xl overflow-hidden border border-brand-200 animate-fade-in">
        <div className="p-12 text-center border-b border-brand-50">
          <Logo className="w-20 h-20 mx-auto mb-6" />
          <h1 className="text-4xl font-black uppercase italic tracking-tighter text-brand-900 leading-none mb-2">
            {viewState === 'login' ? 'Login' : viewState === 'register' ? 'Register' : 'Reset'}
          </h1>
          <p className="text-[10px] font-black text-brand-500 uppercase tracking-[0.5em] italic">
            {viewState === 'forgot' ? 'Recover Access' : 'Access Command Center'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="p-12 space-y-8">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4 italic">Email Address</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl p-6 text-sm focus:border-brand-500 outline-none transition-all shadow-inner" placeholder="user@domain.com" required />
          </div>
          
          {viewState !== 'forgot' && (
            <div className="space-y-2 relative">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4 italic">Password</label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl p-6 text-sm focus:border-brand-500 outline-none transition-all shadow-inner" placeholder="••••••••" required />
            </div>
          )}

          {error && <div className="p-4 bg-rose-50 border border-rose-100 rounded-xl text-rose-600 text-[10px] font-black uppercase text-center italic">{error}</div>}
          {success && (
            <div className="space-y-4">
              <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-xl text-emerald-600 text-[10px] font-black uppercase text-center italic">{success}</div>
              <p className="text-[9px] text-slate-400 font-bold uppercase text-center leading-relaxed">
                Check your spam folder. If you don't receive it within 5 minutes, ensure the email is registered or contact the regional administrator.
              </p>
            </div>
          )}

          <button disabled={loading || (viewState === 'forgot' && resendTimer > 0)} type="submit" className="w-full py-7 bg-brand-900 text-white rounded-[2rem] font-black uppercase text-xs tracking-widest shadow-xl transition-all active:scale-95 italic disabled:opacity-50">
            {loading ? 'Processing...' : viewState === 'login' ? 'Confirm Login' : viewState === 'register' ? 'Create Account' : resendTimer > 0 ? `Resend in ${resendTimer}s` : 'Send Reset Link'}
          </button>
          
          <div className="flex flex-col gap-4">
            <button type="button" onClick={() => setViewState(viewState === 'login' ? 'register' : 'login')} className="w-full text-[10px] font-black text-brand-500 uppercase tracking-widest italic hover:underline">
              {viewState === 'login' ? 'Need an account? Register here' : 'Already registered? Login here'}
            </button>
            {viewState === 'login' && (
              <button type="button" onClick={() => setViewState('forgot')} className="w-full text-[10px] font-black text-slate-400 uppercase tracking-widest italic hover:underline">
                Forgot your password?
              </button>
            )}
            {viewState === 'forgot' && (
              <div className="flex flex-col gap-4">
                <button type="button" onClick={() => setViewState('login')} className="w-full text-[10px] font-black text-slate-400 uppercase tracking-widest italic hover:underline">
                  Back to Login
                </button>
                <button type="button" onClick={() => setViewState('register')} className="w-full text-[10px] font-black text-brand-500 uppercase tracking-widest italic hover:underline">
                  Don't have an account? Register here
                </button>
              </div>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};
