
import React, { useEffect, useRef, useState } from 'react';
import { Bin, BinStatus, Coordinates } from '../types';

declare global {
  interface Window {
    L: any;
  }
}

interface MapVisualizerProps {
  bins: Bin[];
  onBinClick: (bin: Bin) => void;
  highlightedIds?: string[];
  routePath?: Coordinates[]; 
  districtFilter: string | 'ALL';
  userLocation?: Coordinates | null; 
  routeInfo?: { distance: string, duration: string, targetId?: string, streetName?: string } | null;
  center?: Coordinates | null;
}

export const MapVisualizer: React.FC<MapVisualizerProps> = ({ 
  bins, 
  onBinClick, 
  routePath = [], 
  userLocation,
  routeInfo,
  center
}) => {
  const mapRef = useRef<any>(null);
  const mapInstanceRef = useRef<any>(null);
  const markersRef = useRef<{ [key: string]: any }>({});
  const userMarkerRef = useRef<any>(null);
  const routeLineRef = useRef<any>(null);
  const routeDotsRef = useRef<any[]>([]);
  const [mapReady, setMapReady] = useState(false);
  const [maneuver, setManeuver] = useState<{ icon: string, text: string }>({ icon: 'fa-arrow-up', text: 'TACTICAL APPROACH' });
  const [autoFollow, setAutoFollow] = useState(false);
  const [isMoving, setIsMoving] = useState(false);
  const lastPosRef = useRef<Coordinates | null>(null);

  // Helper to calculate bearing between two points
  const calculateBearing = (start: Coordinates, end: Coordinates) => {
    const lat1 = start.lat * Math.PI / 180;
    const lat2 = end.lat * Math.PI / 180;
    const dLon = (end.lng - start.lng) * Math.PI / 180;

    const y = Math.sin(dLon) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) -
              Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
    return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
  };

  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;
    if (window.L) {
        // Leaflet uses Spherical Mercator (EPSG:3857) by default.
        const map = window.L.map(mapRef.current, { 
          zoomControl: false,
          maxZoom: 20,
          fadeAnimation: true,
          zoomSnap: 0.1
        }).setView([13.067677, 80.216335], 15);
        
        window.L.tileLayer('https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
            attribution: 'Google Maps'
        }).addTo(map);
        
        mapInstanceRef.current = map;
        setMapReady(true);
        setTimeout(() => map.invalidateSize(), 800);

        const stopAutoFollow = () => setAutoFollow(false);
        map.on('dragstart', stopAutoFollow);
        map.on('zoomstart', stopAutoFollow);
        map.on('mousedown', stopAutoFollow);
        map.on('touchstart', stopAutoFollow);
        
        const container = map.getContainer();
        container.addEventListener('wheel', stopAutoFollow, { passive: true });
        container.addEventListener('mousedown', stopAutoFollow);
        container.addEventListener('touchstart', stopAutoFollow);
    }
  }, []);

  // Maneuver detection logic (Turns)
  useEffect(() => {
    if (routePath.length > 1 && userLocation) {
      // Movement detection
      if (lastPosRef.current) {
        const dist = Math.sqrt(
          Math.pow(userLocation.lat - lastPosRef.current.lat, 2) + 
          Math.pow(userLocation.lng - lastPosRef.current.lng, 2)
        );
        // Roughly 5-10 meters threshold in degrees
        if (dist > 0.00005) setIsMoving(true);
      } else {
        lastPosRef.current = userLocation;
      }

      if (routeInfo?.duration === '0M 0S') {
         setManeuver({ icon: 'fa-location-dot', text: 'DESTINATION REACHED' });
         return;
      }

      // Find closest index on path
      let closestIdx = 0;
      let minDist = Infinity;
      routePath.forEach((p, i) => {
         const d = Math.sqrt(Math.pow(p.lat - userLocation.lat, 2) + Math.pow(p.lng - userLocation.lng, 2));
         if (d < minDist) { minDist = d; closestIdx = i; }
      });

      // Detect turn by comparing current bearing to bearing 10 points ahead
      if (closestIdx < routePath.length - 15) {
         const currentP = routePath[closestIdx];
         const nextP = routePath[closestIdx + 3] || routePath[routePath.length - 1];
         const farP = routePath[closestIdx + 12] || routePath[routePath.length - 1];

         const bearingNow = calculateBearing(currentP, nextP);
         const bearingLater = calculateBearing(nextP, farP);
         
         let diff = bearingLater - bearingNow;
         if (diff > 180) diff -= 360;
         if (diff < -180) diff += 360;

         // Sensitivity threshold for turns
         if (diff > 22) setManeuver({ icon: 'fa-arrow-turn-right', text: 'TURN RIGHT' });
         else if (diff < -22) setManeuver({ icon: 'fa-arrow-turn-left', text: 'TURN LEFT' });
         else setManeuver({ icon: 'fa-arrow-up', text: 'CONTINUE STRAIGHT' });
      } else {
         setManeuver({ icon: 'fa-location-arrow', text: 'APPROACHING TARGET' });
      }
    }
  }, [routePath, userLocation, routeInfo]);

  // Update bin markers
  useEffect(() => {
    if (!mapInstanceRef.current || !window.L || !mapReady) return;
    bins.forEach(bin => {
        const isLive = !!bin.lastHardwareUpdate;
        const isRecentlyUpdated = isLive && (new Date().getTime() - new Date(bin.lastHardwareUpdate!).getTime() < 30000);
        const color = !isLive ? '#94a3b8' : bin.status === BinStatus.CRITICAL ? '#EF4444' : bin.status === BinStatus.WARNING ? '#F59E0B' : '#10b981';
        const isTarget = routeInfo?.targetId === bin.id;
        const icon = window.L.divIcon({
            className: 'custom-bin-marker',
            html: `<div class="marker-container ${isTarget ? 'is-active' : ''} ${isRecentlyUpdated ? 'is-live' : ''}" style="--marker-c: ${color};"><div class="marker-pin shadow-lg border-2 border-white"></div></div>`,
            iconSize: [24, 24], iconAnchor: [12, 12]
        });
        if (markersRef.current[bin.id]) {
            markersRef.current[bin.id].setLatLng([bin.coordinates.lat, bin.coordinates.lng]);
            markersRef.current[bin.id].setIcon(icon);
        } else {
            markersRef.current[bin.id] = window.L.marker([bin.coordinates.lat, bin.coordinates.lng], { icon }).addTo(mapInstanceRef.current).on('click', () => onBinClick(bin));
        }
    });
  }, [bins, mapReady, routeInfo]);

  // Update user truck position
  useEffect(() => {
    if (!mapInstanceRef.current || !window.L || !userLocation || !mapReady) return;
    const userIcon = window.L.divIcon({
        className: 'user-pos-marker',
        html: `<div class="user-orb shadow-2xl border-4 border-white bg-blue-600 flex items-center justify-center text-white"><i class="fa-solid fa-truck-moving text-sm"></i></div>`,
        iconSize: [40, 40], iconAnchor: [20, 20]
    });
    if (userMarkerRef.current) userMarkerRef.current.setLatLng([userLocation.lat, userLocation.lng]);
    else userMarkerRef.current = window.L.marker([userLocation.lat, userLocation.lng], { icon: userIcon }).addTo(mapInstanceRef.current);
    
    if (autoFollow && routeInfo?.targetId) {
      mapInstanceRef.current.panTo([userLocation.lat, userLocation.lng], { animate: true, duration: 1.0 });
    }
  }, [userLocation, mapReady, autoFollow, routeInfo]);

  // Handle external center requests
  useEffect(() => {
    if (!mapInstanceRef.current || !center || !mapReady) return;
    setAutoFollow(false);
    mapInstanceRef.current.setView([center.lat, center.lng], 18, { animate: true });
  }, [center, mapReady]);

  // Dynamic Path Pruning: Only show dots/lines ahead of the user
  useEffect(() => {
    if (!mapInstanceRef.current || !window.L || !mapReady) return;
    
    // Clear old route visual elements
    if (routeLineRef.current) mapInstanceRef.current.removeLayer(routeLineRef.current);
    routeDotsRef.current.forEach(dot => mapInstanceRef.current.removeLayer(dot));
    routeDotsRef.current = [];

    if (routePath && routePath.length > 1) {
        let forwardPath = routePath;
        if (userLocation) {
           let closestIdx = 0;
           let minDist = Infinity;
           routePath.forEach((p, i) => {
              const d = Math.sqrt(Math.pow(p.lat - userLocation.lat, 2) + Math.pow(p.lng - userLocation.lng, 2));
              if (d < minDist) { minDist = d; closestIdx = i; }
           });
           // Remove all points behind the user
           forwardPath = routePath.slice(closestIdx);
        }

        const latlngs = forwardPath.map(c => [c.lat, c.lng]);
        
        // Main forward path line
        routeLineRef.current = window.L.polyline(latlngs, { 
           color: '#3B82F6', 
           weight: 6, 
           opacity: 0.6, 
           lineCap: 'round', 
           lineJoin: 'round'
        }).addTo(mapInstanceRef.current);

        // Add visual dots for the forward path only
        // Sampling dots every 5 points to avoid clutter
        for (let i = 0; i < forwardPath.length; i += 4) {
          const p = forwardPath[i];
          const dot = window.L.circleMarker([p.lat, p.lng], {
            radius: 4,
            fillColor: '#3B82F6',
            color: '#fff',
            weight: 1.5,
            fillOpacity: 0.9,
            className: 'path-dot-indicator'
          }).addTo(mapInstanceRef.current);
          routeDotsRef.current.push(dot);
        }
    }
  }, [routePath, mapReady, userLocation]);

  return (
    <div className="relative w-full h-full bg-slate-100 overflow-hidden">
      <div ref={mapRef} className="w-full h-full z-0"></div>
      
      {/* Top Status Bar */}
      <div className="absolute top-6 left-6 z-[1000] pointer-events-none">
        <div className="bg-white/95 backdrop-blur-md border border-slate-200 px-5 py-2 rounded-full flex items-center gap-3 shadow-xl">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
          <span className="text-slate-900 font-black text-[10px] uppercase tracking-[0.1em] italic">
            {bins.filter(b=>!!b.lastHardwareUpdate).length} NODES SYNCED
          </span>
        </div>
      </div>

      {/* Auto-follow button */}
      {(!autoFollow || !routeInfo) && (
        <div className="absolute bottom-40 right-6 z-[1000] flex flex-col gap-3">
          <button 
            onClick={() => {
              if (userLocation) {
                mapInstanceRef.current.setView([userLocation.lat, userLocation.lng], 17, { animate: true });
                // Only enable auto-follow if we are actually in a mission
                if (routeInfo) setAutoFollow(true);
              }
            }} 
            className="w-14 h-14 bg-white border border-slate-200 rounded-full shadow-2xl flex items-center justify-center text-brand-900 active:scale-95 transition-all"
            title="My Location"
          >
            <i className="fa-solid fa-location-crosshairs text-xl"></i>
          </button>
          
          {routeInfo && !autoFollow && (
            <button 
              onClick={() => setAutoFollow(true)} 
              className="w-14 h-14 bg-brand-900 rounded-full shadow-4xl flex items-center justify-center text-white active:scale-95 transition-all animate-pulse"
              title="Resume Auto-Follow"
            >
              <i className="fa-solid fa-route text-xl"></i>
            </button>
          )}
        </div>
      )}

      {/* Zoom Controls */}
      <div className="absolute top-24 right-6 z-[1000] flex flex-col gap-2">
        <button 
          onClick={() => mapInstanceRef.current.zoomIn()}
          className="w-10 h-10 bg-white border border-slate-200 rounded-xl shadow-lg flex items-center justify-center text-brand-900 hover:bg-slate-50 active:scale-95 transition-all"
        >
          <i className="fa-solid fa-plus"></i>
        </button>
        <button 
          onClick={() => mapInstanceRef.current.zoomOut()}
          className="w-10 h-10 bg-white border border-slate-200 rounded-xl shadow-lg flex items-center justify-center text-brand-900 hover:bg-slate-50 active:scale-95 transition-all"
        >
          <i className="fa-solid fa-minus"></i>
        </button>
      </div>

      {/* Navigation HUD */}
      {routeInfo && (
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-[1001] w-full max-w-lg px-6 animate-fade-in">
             <div className="bg-[#0f172a]/95 backdrop-blur-2xl border border-white/10 rounded-[2.5rem] p-4 shadow-[0_30px_60px_rgba(0,0,0,0.4)] flex items-center justify-between text-white overflow-hidden ring-1 ring-white/20">
                <div className="flex items-center gap-5 pl-2">
                    <div className={`w-16 h-16 ${!isMoving ? 'bg-slate-700' : maneuver.text.includes('REACHED') ? 'bg-emerald-500 shadow-[0_0_30px_#10b981]' : (maneuver.text.includes('LEFT') || maneuver.text.includes('RIGHT')) ? 'bg-amber-500 shadow-[0_0_20px_#f59e0b]' : 'bg-[#2563EB] shadow-[0_0_20px_rgba(37,99,235,0.6)]'} rounded-full flex items-center justify-center text-white text-3xl transition-all`}>
                      <i className={`fa-solid ${!isMoving ? 'fa-pause animate-pulse' : maneuver.icon}`}></i>
                    </div>
                    <div className="flex flex-col">
                        <span className="text-[9px] text-slate-400 font-black uppercase tracking-[0.4em] mb-1 italic opacity-80 leading-none truncate max-w-[180px]">TARGET: {routeInfo.streetName?.toUpperCase()}</span>
                        <h4 className="text-xl font-black italic tracking-tighter leading-none uppercase text-white">
                          {!isMoving ? 'WAITING FOR MOVEMENT' : maneuver.text}
                        </h4>
                    </div>
                </div>
                <div className="flex flex-col items-end pr-8">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] italic leading-none opacity-80 mb-2">DYNAMIC ETA</p>
                    <p className={`text-2xl font-black italic uppercase leading-none tracking-tight ${maneuver.text.includes('REACHED') ? 'text-emerald-400' : 'text-white'}`}>{routeInfo.duration === '0M 0S' ? 'ARRIVED' : routeInfo.duration}</p>
                </div>
             </div>
          </div>
      )}

      <style>{`
        .marker-pin { width: 18px; height: 18px; background-color: var(--marker-c); border-radius: 50%; transition: all 0.5s ease; } 
        .is-active .marker-pin { transform: scale(1.8); box-shadow: 0 0 30px var(--marker-c); animation: markerPulse 1.2s infinite alternate; } 
        .is-live .marker-pin { box-shadow: 0 0 15px var(--marker-c); animation: livePulse 2s infinite; }
        @keyframes markerPulse { from { transform: scale(1.6); } to { transform: scale(2.0); } } 
        @keyframes livePulse { 0% { box-shadow: 0 0 0 0px var(--marker-c); } 70% { box-shadow: 0 0 0 15px rgba(0, 0, 0, 0); } 100% { box-shadow: 0 0 0 0px rgba(0, 0, 0, 0); } }
        .user-orb { border-radius: 50%; box-shadow: 0 0 30px rgba(37, 99, 235, 0.6); } 
        .leaflet-div-icon { background: transparent !important; border: none !important; }
        .path-dot-indicator { filter: drop-shadow(0 0 4px rgba(59, 130, 246, 0.5)); transition: opacity 0.3s ease; }
      `}</style>
    </div>
  );
};
