
import React from 'react';

// 1. Export your logo from Figma as PNG or SVG
// 2. Upload it to a host (like Imgur)
// 3. Paste the DIRECT link (ending in .png or .svg) below
const LOGO_URL = "https://i.postimg.cc/fbbwRRgS/logo-removebg-preview.png"; 

export const Logo: React.FC<{ className?: string, color?: string }> = ({ className = "w-12 h-12", color = "#2563eb" }) => {
  if (LOGO_URL) {
    return (
      <div className={`${className} flex items-center justify-center select-none overflow-hidden`}>
        <img 
          src={LOGO_URL} 
          alt="Neuro Bin Logo" 
          className="w-full h-full object-contain"
          referrerPolicy="no-referrer"
        />
      </div>
    );
  }

  return (
    <div className={`${className} flex items-center justify-center select-none`}>
      <svg viewBox="0 0 100 120" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Top horizontal rounded bar */}
        <rect x="10" y="12" width="80" height="6" rx="3" fill={color} />
        
        {/* 3-Arrow Recycling Loop - Optimized for "Bin" shape */}
        {/* Right Arrow (Down) */}
        <path d="M82 28 L74 105" stroke={color} strokeWidth="5.5" strokeLinecap="round" />
        <path d="M68 96 L74 105 L82 98" stroke={color} strokeWidth="5.5" strokeLinecap="round" strokeLinejoin="round" />
        
        {/* Bottom Arrow (Left) */}
        <path d="M74 105 L26 105" stroke={color} strokeWidth="5.5" strokeLinecap="round" />
        <path d="M34 113 L26 105 L34 97" stroke={color} strokeWidth="5.5" strokeLinecap="round" strokeLinejoin="round" />
        
        {/* Left Arrow (Up) */}
        <path d="M26 105 L18 28" stroke={color} strokeWidth="5.5" strokeLinecap="round" />
        <path d="M12 37 L18 28 L26 35" stroke={color} strokeWidth="5.5" strokeLinecap="round" strokeLinejoin="round" />

        {/* Cursive "NEU" and "RO" text - Precisely centered */}
        <text 
          x="50" 
          y="60" 
          textAnchor="middle" 
          fill={color} 
          style={{ 
            fontFamily: "'Dancing Script', cursive", 
            fontSize: '18px', 
            fontWeight: 'bold',
            fontStyle: 'italic'
          }}
        >
          NEU
        </text>
        <text 
          x="50" 
          y="88" 
          textAnchor="middle" 
          fill={color} 
          style={{ 
            fontFamily: "'Dancing Script', cursive", 
            fontSize: '24px', 
            fontWeight: 'bold',
            fontStyle: 'italic'
          }}
        >
          RO
        </text>
      </svg>
    </div>
  );
};
