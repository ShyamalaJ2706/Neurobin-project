
import React, { useState, useEffect, useRef } from 'react';
import { Bin, BinStatus } from '../types';
import { Logo } from './Logo';

declare const QRCode: any;

interface BinCardProps {
  bin: Bin;
  onNavigate?: (bin: Bin) => void;
  onDispatch?: (bin: Bin) => void;
  onUpdateDepth?: (binId: string, newDepth: number) => void;
}

export const BinCard: React.FC<BinCardProps> = ({ 
  bin, 
  onNavigate, 
  onDispatch, 
  onUpdateDepth
}) => {
  const [showSettings, setShowSettings] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showQR, setShowQR] = useState(false);
  const [tempDepth, setTempDepth] = useState(bin.depth.toString());
  const qrRef = useRef<HTMLDivElement>(null);

  const isLive = !!bin.lastHardwareUpdate;

  useEffect(() => {
    if (showQR && qrRef.current) {
      qrRef.current.innerHTML = "";
      const feedbackUrl = 'https://docs.google.com/forms/d/e/1FAIpQLSdssVVXoQ-eNz4_tRtmsltZothNXT-1psES0bFivaOOk3F0Mg/viewform?usp=header';
      new QRCode(qrRef.current, {
        text: feedbackUrl,
        width: 320,
        height: 320,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H
      });
    }
  }, [showQR, bin.id]);

  const getStatusColor = (status: BinStatus) => {
    switch (status) {
      case BinStatus.CRITICAL: return 'bg-rose-500';
      case BinStatus.WARNING: return 'bg-amber-500';
      default: return 'bg-emerald-500';
    }
  };

  const handleApplyDepth = () => {
    const d = parseFloat(tempDepth);
    if (!isNaN(d) && d > 0) {
      onUpdateDepth?.(bin.id, d);
      setShowSettings(false);
    }
  };

  const isDistanceLogGreen = parseFloat(bin.sensorReading.toString()) < 10;

  return (
    <div className="bg-white rounded-2xl border border-brand-200 shadow-sm p-3 hover:shadow-lg transition-all flex flex-col h-full group relative overflow-hidden">
      {/* Background Watermark */}
      <div className="absolute top-0 right-0 p-2 opacity-[0.01] group-hover:opacity-[0.03] transition-opacity font-black text-5xl italic select-none">
        {bin.id.split('-')[1]}
      </div>

      <div className="flex justify-between items-start mb-2 z-10">
        <div className="text-left">
          <div className="flex items-center gap-1 mb-1">
             <span className={`w-1 h-1 rounded-full ${getStatusColor(bin.status)} ${isLive ? 'animate-pulse shadow-[0_0_4px_currentColor]' : ''}`}></span>
             <span className="text-[6px] font-black text-brand-400 uppercase tracking-widest italic">{bin.district}</span>
          </div>
          <h3 className="text-brand-900 font-black text-sm tracking-tighter uppercase italic leading-none mb-1 truncate max-w-[120px]" title={bin.streetName}>{bin.streetName}</h3>
          <p className="text-[5px] text-brand-500 font-mono font-black tracking-widest bg-brand-50 px-1 py-0.5 rounded-full inline-block border border-brand-100 uppercase">{bin.id}</p>
        </div>
        <div className="flex gap-1">
          <button 
            onClick={() => setShowHistory(!showHistory)} 
            className={`w-6 h-6 rounded-lg flex items-center justify-center border transition-all ${showHistory ? 'bg-brand-500 text-white border-brand-500' : 'bg-brand-50 text-brand-400 border-brand-200 hover:text-brand-500'}`}
            title="Collection History"
          >
            <i className="fa-solid fa-clock-rotate-left text-[8px]"></i>
          </button>
          <button onClick={() => setShowSettings(!showSettings)} className={`w-6 h-6 rounded-lg flex items-center justify-center border transition-all ${showSettings ? 'bg-brand-900 text-white border-brand-900' : 'bg-brand-50 text-brand-400 border-brand-200 hover:text-brand-900'}`}>
            <i className="fa-solid fa-sliders text-[8px]"></i>
          </button>
        </div>
      </div>

      <div className="flex-1 flex gap-2 z-10 relative">
        {(showSettings || showHistory) && (
          <div className="absolute inset-0 bg-white/98 backdrop-blur-md z-20 flex flex-col gap-1.5 animate-fade-in p-1.5 border border-brand-100 rounded-xl shadow-2xl overflow-hidden">
             {showSettings ? (
                <div className="p-1.5">
                   <span className="text-[6px] font-black text-brand-900 uppercase tracking-widest mb-1.5 block italic">Calibration Config</span>
                   <div className="flex gap-1.5">
                      <input type="number" value={tempDepth} onChange={(e) => setTempDepth(e.target.value)} className="flex-1 bg-white border border-brand-200 rounded-lg px-2 py-1 text-xs font-black outline-none focus:border-brand-500" />
                      <button onClick={handleApplyDepth} className="px-2 bg-brand-900 text-white rounded-lg font-black text-[6px] uppercase italic">Save</button>
                   </div>
                </div>
             ) : (
                <div className="flex flex-col h-full overflow-hidden">
                   <div className="flex justify-between items-center mb-1.5 px-1">
                     <span className="text-[6px] font-black text-brand-500 uppercase tracking-widest italic">Collection Audit Feed</span>
                     <span className="text-[5px] font-black bg-brand-50 text-brand-400 px-1 rounded">{bin.history?.length || 0} hits</span>
                   </div>
                   <div className="flex-1 overflow-y-auto custom-scroll space-y-1 pr-1 pb-1.5">
                     {bin.history && bin.history.length > 0 ? [...bin.history].reverse().map((h, i) => (
                       <div key={i} className="bg-white p-2 rounded-lg border border-brand-100 flex flex-col gap-1.5 shadow-sm group/log transition-all hover:border-brand-300">
                         <div className="flex justify-between items-start">
                            <div className="text-[7px] font-black text-brand-900 leading-tight">
                               {new Date(h.timestamp).toLocaleDateString()}<br/>
                               <span className="text-brand-400 font-mono text-[6px]">{new Date(h.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                            </div>
                            <div className="flex flex-col items-end">
                               <span className="text-[5px] font-black uppercase text-brand-400 block mb-0.5">Operator</span>
                               <span className="text-[6px] font-black uppercase text-brand-900 bg-brand-50 px-1.5 py-0.5 rounded-md border border-brand-100 italic leading-none">{h.operator}</span>
                            </div>
                         </div>
                         <div className="flex items-center justify-between border-t border-brand-50 pt-1">
                            <div className="flex items-center gap-1">
                               <i className="fa-solid fa-weight-hanging text-brand-300 text-[7px]"></i>
                               <span className="text-[6px] font-black text-brand-500 uppercase italic">Collection Load:</span>
                            </div>
                            <span className={`text-[9px] font-black italic ${h.fillLevelAtCollection && h.fillLevelAtCollection > 80 ? 'text-rose-500' : 'text-emerald-600'}`}>
                               {h.fillLevelAtCollection || '??'}%
                            </span>
                         </div>
                       </div>
                     )) : (
                       <div className="h-full flex flex-col items-center justify-center py-4 opacity-30">
                          <i className="fa-solid fa-folder-open text-lg mb-1.5 text-brand-200"></i>
                          <p className="text-[6px] font-black uppercase tracking-widest">No Operational Records</p>
                       </div>
                     )}
                   </div>
                </div>
             )}
             <button onClick={() => {setShowSettings(false); setShowHistory(false);}} className="w-full py-2 mt-auto text-[7px] font-black uppercase text-brand-900 hover:bg-brand-50 border-t border-brand-100 transition-colors">Dismiss Intelligence Overlay</button>
          </div>
        )}

        {/* Telemetry Bar */}
        <div className="w-12 h-28 bg-brand-50 rounded-xl border border-brand-200 shadow-inner relative flex flex-col justify-end p-1 overflow-hidden shrink-0">
           <div className="absolute top-1.5 left-0 w-full text-center text-[4px] font-black text-brand-200 uppercase tracking-widest z-0">Telemetry</div>
           <div 
             className={`w-full rounded-lg transition-all duration-1000 ${getStatusColor(bin.status)} shadow-lg flex items-center justify-center relative overflow-hidden`}
             style={{ height: `${bin.fillLevel}%`, minHeight: '12%' }}
           >
              <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent"></div>
              <span className="text-white text-[5px] font-black rotate-90 opacity-40 tracking-widest uppercase">Loaded</span>
           </div>
        </div>

        <div className="flex-1 flex flex-col justify-center space-y-1.5">
           <div className="bg-brand-50 rounded-lg p-2 border border-brand-200 relative overflow-hidden group-hover:bg-white transition-colors">
              <span className="text-[5px] font-black text-brand-400 uppercase tracking-widest block mb-0.5 italic">Sensor Delta</span>
              <div className="flex items-baseline gap-1">
                 <span className={`text-xl font-black tracking-tighter italic ${isDistanceLogGreen ? 'text-emerald-600' : 'text-brand-900'}`}>{bin.sensorReading}</span>
                 <span className="text-[6px] font-black text-brand-300 uppercase italic">cm</span>
              </div>
           </div>
           <div className="grid grid-cols-2 gap-1">
              <div className="bg-brand-50 p-1 rounded-lg border border-brand-100">
                 <span className="text-[4px] font-black text-brand-400 uppercase italic">Fill</span>
                 <span className={`text-[10px] font-black italic block ${bin.fillLevel > 80 ? 'text-rose-500' : 'text-brand-900'}`}>{bin.fillLevel}%</span>
              </div>
              <div className="bg-brand-50 p-1 rounded-lg border border-brand-100">
                 <span className="text-[4px] font-black text-brand-400 uppercase italic">Last Collection</span>
                 <span className="text-[7px] font-black text-brand-900 italic block truncate">
                    {bin.history && bin.history.length > 0 ? (
                       <>
                          {bin.history[bin.history.length - 1].operator} • {new Date(bin.history[bin.history.length - 1].timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                       </>
                    ) : bin.lastCollection ? (
                       new Date(bin.lastCollection).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                    ) : 'N/A'}
                 </span>
              </div>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-1.5 mt-2 pt-2 border-t border-brand-100 z-10">
        <button onClick={() => setShowQR(true)} className="py-1.5 bg-brand-50 hover:bg-brand-100 text-brand-400 rounded-lg text-[6px] font-black uppercase tracking-widest italic border border-brand-200 transition-all">
           Unit Tag
        </button>
        <button 
          onClick={() => onDispatch?.(bin)}
          className="py-1.5 bg-brand-900 hover:bg-black text-white rounded-lg text-[6px] font-black uppercase tracking-widest italic shadow-sm active:scale-95 transition-all"
        >
          Route Fleet
        </button>
      </div>

      {showQR && (
        <div className="fixed inset-0 bg-brand-900/95 backdrop-blur-3xl z-[9999] flex items-center justify-center p-6 animate-fade-in">
           <div className="bg-white rounded-[2rem] p-8 w-full max-w-sm shadow-4xl relative flex flex-col items-center">
             <button onClick={() => setShowQR(false)} className="absolute top-6 right-6 text-brand-300 hover:text-brand-900">
               <i className="fa-solid fa-xmark text-xl"></i>
             </button>
             <div className="bg-white p-3 rounded-[1.5rem] shadow-2xl border border-brand-50 flex flex-col items-center relative mb-8">
                <div ref={qrRef} className="p-2 bg-white" style={{ width: '220px', height: '220px' }}></div>
                <div className="absolute top-[132px] left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
                    <div className="bg-white p-2 rounded-lg shadow-2xl border border-brand-50"><Logo className="w-8 h-8" /></div>
                </div>
             </div>
             <div className="text-center">
               <p className="text-[8px] font-black text-brand-500 uppercase tracking-[0.4em] italic mb-2">Municipal Signature</p>
               <h4 className="text-4xl font-black text-brand-900 italic tracking-tighter uppercase leading-none">{bin.id}</h4>
             </div>
           </div>
        </div>
      )}
    </div>
  );
};
