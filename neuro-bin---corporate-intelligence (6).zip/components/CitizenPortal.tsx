
import React, { useState, useEffect, useRef } from 'react';
import { Bin, Coordinates, CitizenReport, BinStatus, User } from '../types';
import { submitReport, subscribeToReports, updatePassword } from '../services/firebaseService';
import { QRScanner } from './QRScanner';
import { LoginPage } from './LoginPage';

interface CitizenPortalProps {
  bin: Bin | null;
  bins: Bin[];
  user: User | null;
  onLogin: (user: User) => void;
  onRegister: (user: User) => void;
  onLogout: () => void;
  onBackToLanding: () => void;
  surveyUrl: string;
}

export const CitizenPortal: React.FC<CitizenPortalProps> = ({ 
  bin: initialBin, 
  bins, 
  user, 
  onLogin, 
  onRegister, 
  onLogout,
  onBackToLanding,
  surveyUrl: rawSurveyUrl
}) => {
  const surveyUrl = rawSurveyUrl.includes('viewform') ? rawSurveyUrl : rawSurveyUrl.replace('/formResponse', '/viewform') + (rawSurveyUrl.includes('?') ? '&' : '?') + 'embedded=true';
  const [activeTab, setActiveTab] = useState<'form' | 'tracking' | 'explore' | 'lookup' | 'profile' | 'survey'>(initialBin ? 'form' : 'lookup');
  const [currentBin, setCurrentBin] = useState<Bin | null>(initialBin);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResult, setSearchResult] = useState<Bin | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [passwordStatus, setPasswordStatus] = useState<{ type: 'success' | 'error', msg: string } | null>(null);
  const [passwordLoading, setPasswordLoading] = useState(false);

  useEffect(() => {
    if (initialBin) {
      setCurrentBin(initialBin);
      setActiveTab('form');
    }
  }, [initialBin]);
  const [isScanning, setIsScanning] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [reportType, setReportType] = useState('overflow');
  const [message, setMessage] = useState('');
  const [userCoords, setUserCoords] = useState<Coordinates | null>(null);
  const [locationName, setLocationName] = useState<string>('');
  const [allReports, setAllReports] = useState<CitizenReport[]>([]);
  const [myReportIds, setMyReportIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('neuro_my_reports');
    return saved ? JSON.parse(saved) : [];
  });
  
  const mapRef = useRef<HTMLDivElement>(null);
  const exploreMapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any>(null);
  const exploreMapInstance = useRef<any>(null);

  useEffect(() => {
    requestLocation();
    const unsub = subscribeToReports((data) => {
      const list = data ? Object.entries(data).map(([id, val]: [string, any]) => ({ id, ...val })) as CitizenReport[] : [];
      setAllReports(list);
    });
    return () => unsub();
  }, []);

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword) return;
    setPasswordLoading(true);
    setPasswordStatus(null);
    try {
      await updatePassword(newPassword);
      setPasswordStatus({ type: 'success', msg: 'Password updated successfully.' });
      setNewPassword('');
    } catch (err: any) {
      setPasswordStatus({ type: 'error', msg: err.message });
    } finally {
      setPasswordLoading(false);
    }
  };

  const requestLocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const coords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          setUserCoords(coords);
          setLocationName("Active Regional Sector");
        },
        () => {},
        { enableHighAccuracy: true, timeout: 10000 }
      );
    }
  };

  useEffect(() => {
    if (activeTab === 'form' && userCoords && mapRef.current && !mapInstance.current && (window as any).L) {
      const L = (window as any).L;
      const map = L.map(mapRef.current, { zoomControl: false, attributionControl: false }).setView([userCoords.lat, userCoords.lng], 16);
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png').addTo(map);
      const icon = L.divIcon({ className: 'gps-marker', html: `<div class="w-8 h-8 bg-brand-500 rounded-full border-4 border-white shadow-xl animate-pulse"></div>`, iconSize: [32, 32], iconAnchor: [16, 16] });
      L.marker([userCoords.lat, userCoords.lng], { icon }).addTo(map);
      mapInstance.current = map;
    }
  }, [userCoords, activeTab]);

  useEffect(() => {
    if (activeTab === 'explore' && exploreMapRef.current && (window as any).L) {
      const L = (window as any).L;
      if (exploreMapInstance.current) exploreMapInstance.current.remove();
      
      const center = userCoords || { lat: 12.9698, lng: 80.1144 };
      const map = L.map(exploreMapRef.current, { zoomControl: false }).setView([center.lat, center.lng], 15);
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png').addTo(map);
      
      bins.forEach(b => {
        const color = b.fillLevel > 80 ? '#f43f5e' : '#8b5cf6';
        L.marker([b.coordinates.lat, b.coordinates.lng], {
          icon: L.divIcon({ className: 'b-m', html: `<div style="background:${color}" class="w-10 h-10 rounded-full border-4 border-white shadow-2xl flex items-center justify-center text-[10px] text-white font-black">${b.fillLevel}%</div>` })
        }).addTo(map).on('click', () => {
          setCurrentBin(b);
          setActiveTab('form');
        });
      });
      exploreMapInstance.current = map;
    }
  }, [activeTab, bins, userCoords]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentBin) return;
    setLoading(true);
    try {
      const reportId = await submitReport(
        currentBin.id, 
        reportType, 
        message, 
        userCoords || undefined, 
        locationName, 
        currentBin.streetName,
        user?.username // Pass userId if logged in
      );
      if (reportId) {
        const newIds = [reportId, ...myReportIds];
        setMyReportIds(newIds);
        localStorage.setItem('neuro_my_reports', JSON.stringify(newIds));
        setSubmitted(true);
        setTimeout(() => { setSubmitted(false); setActiveTab('tracking'); setMessage(''); }, 2000);
      }
    } catch (error) { alert("Submission error"); } finally { setLoading(false); }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const found = bins.find(b => b.id.toUpperCase() === searchQuery.toUpperCase());
    if (found) {
      setSearchResult(found);
    } else {
      alert(`Bin ID [${searchQuery}] not found.`);
      setSearchResult(null);
    }
  };

  // Logic: Show reports linked to this user (if logged in) or from localStorage
  const myReports = allReports
    .filter(r => {
      const isLocal = myReportIds.includes(r.id);
      const isUser = user && r.userId === user.username;
      return (isLocal || isUser) && r.status !== 'resolved';
    })
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  if (isScanning) {
    return <QRScanner bins={bins} onScan={(id) => {
        const found = bins.find(b => b.id.toUpperCase() === id.toUpperCase());
        if(found) { setCurrentBin(found); setIsScanning(false); setActiveTab('form'); }
        else alert(`Asset ID [${id}] not registered.`);
    }} onClose={() => setIsScanning(false)} />;
  }

  return (
    <div className="flex flex-col h-full animate-fade-in bg-brand-50/20">
      <div className="flex bg-white border-b border-slate-200 shrink-0 z-10 shadow-sm px-4 overflow-x-auto no-scrollbar">
        {[
          { id: 'lookup', label: 'Search Bin', icon: 'fa-magnifying-glass' },
          { id: 'explore', label: 'Map', icon: 'fa-map' },
          { id: 'form', label: 'Feedback', icon: 'fa-bullhorn' },
          { id: 'tracking', label: 'Feedback Status', icon: 'fa-clipboard-list' },
          { id: 'profile', label: 'Profile', icon: 'fa-user-gear' },
          { id: 'survey', label: 'Survey QR', icon: 'fa-qrcode' }
        ].map(tab => (
          <button 
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)} 
            className={`flex-1 min-w-[80px] py-6 flex flex-col items-center gap-1 text-[11px] font-black uppercase tracking-widest transition-all ${activeTab === tab.id ? 'text-brand-600 border-b-4 border-brand-600 bg-brand-50/50' : 'text-slate-400 hover:text-slate-600'}`}
          >
            <i className={`fa-solid ${tab.icon} text-lg`}></i>
            {tab.label}
          </button>
        ))}
        <button 
          onClick={() => {
            if (user) {
              if (window.confirm("Logout from Citizen Hub?")) onLogout();
            } else {
              setActiveTab('tracking'); // Redirect to tracking which will show login
            }
          }}
          className={`px-6 py-6 flex flex-col items-center gap-1 text-[11px] font-black uppercase tracking-widest transition-all ${user ? 'text-emerald-600' : 'text-slate-400'}`}
        >
          <i className={`fa-solid ${user ? 'fa-user-check' : 'fa-user-lock'} text-lg`}></i>
          {user ? user.username : 'Login'}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto relative p-8 custom-scroll">
        {activeTab === 'explore' && (
          <div className="absolute inset-0 z-0">
            <div ref={exploreMapRef} className="w-full h-full"></div>
            <div className="absolute bottom-12 inset-x-12 bg-slate-900/95 backdrop-blur-2xl p-10 rounded-[3rem] border border-white/10 shadow-4xl z-[1000] flex items-center gap-8 animate-fade-in">
               <div className="w-16 h-16 bg-brand-600 rounded-2xl flex items-center justify-center text-white text-2xl shadow-2xl animate-pulse"><i className="fa-solid fa-radar"></i></div>
               <div>
                  <p className="text-[12px] font-black uppercase italic text-brand-400 tracking-[0.4em] mb-1">Field Explorer</p>
                  <p className="text-white font-bold text-xl tracking-tight leading-none">Select a live node to report</p>
               </div>
            </div>
          </div>
        )}

        <div className={`max-w-2xl mx-auto py-6 ${activeTab === 'explore' ? 'pointer-events-none opacity-0' : 'animate-fade-in'}`}>
          {submitted ? (
            <div className="flex flex-col items-center justify-center text-center py-32 space-y-12">
               <div className="w-32 h-32 bg-brand-500 text-white rounded-[3.5rem] flex items-center justify-center text-6xl shadow-2xl animate-bounce"><i className="fa-solid fa-check"></i></div>
               <div>
                  <h2 className="text-5xl font-black uppercase italic tracking-tighter mb-6 leading-none">Sync Confirmed</h2>
                  <p className="text-slate-500 font-bold text-lg tracking-tight uppercase">Operational resources are in transit.</p>
               </div>
            </div>
          ) : activeTab === 'form' ? (
            <div className="space-y-12">
              {!currentBin ? (
                <div className="text-center py-24 bg-white border border-slate-200 p-16 rounded-[4rem] shadow-xl">
                  <div className="w-40 h-40 bg-brand-50 rounded-[3.5rem] flex items-center justify-center text-brand-600 text-6xl mx-auto mb-16 shadow-inner border border-brand-100 animate-float">
                    <i className="fa-solid fa-qrcode"></i>
                  </div>
                  <h3 className="text-4xl font-black uppercase italic mb-6 tracking-tighter leading-none text-slate-900">Establish Registry Link</h3>
                  <p className="text-slate-400 text-sm mb-16 leading-relaxed font-bold uppercase tracking-widest max-w-sm mx-auto">Scan the optical municipal tag on the physical unit.</p>
                  <button onClick={() => setIsScanning(true)} className="w-full py-8 bg-slate-900 hover:bg-slate-800 text-white rounded-[2.5rem] font-black uppercase text-sm tracking-[0.2em] shadow-2xl transition-all flex items-center justify-center gap-4">
                    <i className="fa-solid fa-expand"></i>
                    Initialize Optical Hub
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-12">
                  {/* Google Form Node - Primary Interface */}
                  <div className="bg-white border-4 border-brand-100 rounded-[4rem] overflow-hidden shadow-2xl relative animate-fade-in">
                    <div className="absolute top-0 inset-x-0 h-2 bg-brand-500"></div>
                    <div className="p-6 bg-brand-50 border-b border-brand-100 flex justify-between items-center">
                      <div>
                        <h4 className="text-xl font-black uppercase italic tracking-tighter text-brand-900 leading-none">Operational Feedback Node</h4>
                        <p className="text-[8px] font-black text-brand-400 uppercase tracking-widest mt-1 italic">Secure Municipal Link</p>
                      </div>
                      <button 
                        type="button"
                        onClick={() => window.open(surveyUrl, '_blank')}
                        className="px-4 py-2 bg-white text-brand-600 rounded-xl font-black uppercase text-[9px] tracking-widest border border-brand-200 hover:bg-brand-50 transition-all shadow-sm flex items-center gap-2"
                      >
                        <i className="fa-solid fa-arrow-up-right-from-square"></i>
                        External View
                      </button>
                    </div>
                    <div className="relative bg-white">
                      <iframe 
                        src={surveyUrl}
                        className="w-full h-[650px] border-none"
                        title="Feedback Form"
                      ></iframe>
                    </div>
                    <div className="p-8 bg-brand-900 text-white text-center">
                      <p className="text-[10px] font-black uppercase tracking-[0.3em] mb-2 italic">Step 1: Complete Official Survey Above</p>
                      <p className="text-[10px] font-black uppercase tracking-[0.3em] italic opacity-60">Step 2: Log Incident Below to Sync with Hub</p>
                    </div>
                  </div>

                  <div className="bg-white rounded-[4rem] p-12 text-slate-900 flex flex-col items-center gap-10 shadow-xl border border-slate-200 relative overflow-hidden group">
                     <div className="w-full flex justify-between items-center border-b border-slate-100 pb-8">
                        <div className="text-left">
                          <span className="text-[11px] font-black text-brand-600 uppercase tracking-widest block italic mb-2">Authenticated Asset</span>
                          <h3 className="text-4xl font-black uppercase italic tracking-tighter text-slate-900 leading-none">{currentBin.streetName}</h3>
                        </div>
                        <button type="button" onClick={() => setIsScanning(true)} className="w-16 h-16 bg-brand-50 rounded-3xl flex items-center justify-center text-2xl hover:bg-brand-100 hover:text-brand-600 border border-brand-200 transition-all shadow-sm"><i className="fa-solid fa-retweet"></i></button>
                     </div>
                     <div className="relative w-64 h-64 flex items-center justify-center">
                        <svg className="w-full h-full transform -rotate-90">
                          <circle cx="128" cy="128" r="115" stroke="#f1f5f9" strokeWidth="20" fill="transparent" />
                          <circle cx="128" cy="128" r="115" stroke={currentBin.fillLevel > 80 ? '#f43f5e' : '#8b5cf6'} strokeWidth="20" fill="transparent" strokeDasharray={722.5} strokeDashoffset={722.5 - (722.5 * currentBin.fillLevel) / 100} strokeLinecap="round" className="transition-all duration-1000" />
                        </svg>
                        <div className="absolute flex flex-col items-center">
                          <span className="text-8xl font-black leading-none tracking-tighter text-slate-900">{currentBin.fillLevel}<span className="text-3xl text-slate-300">%</span></span>
                          <span className="text-[12px] font-black uppercase text-brand-600 tracking-[0.5em] mt-2 italic">Fill Stat</span>
                        </div>
                     </div>
                  </div>

                  <div className="space-y-10">
                    <div className="flex items-center justify-between gap-4 ml-6">
                       <div className="flex items-center gap-4">
                          <span className="w-3 h-3 rounded-full bg-brand-500"></span>
                          <label className="text-[12px] font-black uppercase text-slate-500 tracking-[0.6em] italic">Incident Registry</label>
                       </div>
                    </div>

                    <div className="grid grid-cols-2 gap-6">
                      {[
                        {id:'overflow',l:'Overflow',i:'fa-dumpster-fire'},
                        {id:'damage',l:'Damage',i:'fa-burst'},
                        {id:'odor',l:'Toxic Odor',i:'fa-mask-ventilator'},
                        {id:'other',l:'Manual Alert',i:'fa-bolt-lightning'}
                      ].map(t => (
                        <button key={t.id} type="button" onClick={() => setReportType(t.id)} className={`flex flex-col items-center gap-6 p-12 rounded-[3.5rem] border-4 transition-all duration-300 ${reportType === t.id ? 'bg-brand-600 border-brand-600 text-white shadow-2xl scale-105' : 'bg-white border-slate-200 text-slate-400 hover:border-brand-200 hover:text-brand-600 shadow-sm'}`}>
                          <i className={`fa-solid ${t.i} text-5xl`}></i>
                          <span className="text-[11px] font-black uppercase tracking-[0.2em]">{t.l}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <textarea 
                    value={message} 
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full h-48 bg-white border-4 border-slate-100 rounded-[3rem] p-12 text-slate-900 text-xl font-medium italic focus:border-brand-500 outline-none transition-all placeholder-slate-300 shadow-xl" 
                    placeholder="Brief operational message to the Regional Hub..." 
                  />

                  <button disabled={loading} type="submit" className="w-full py-10 bg-slate-900 hover:bg-slate-800 text-white rounded-[3.5rem] font-black uppercase text-sm tracking-[0.3em] shadow-4xl active:scale-95 transition-all mb-20 italic">
                    {loading ? <i className="fa-solid fa-circle-notch animate-spin text-3xl"></i> : 'Transmit Signal to Hub'}
                  </button>
                </form>
              )}
            </div>
          ) : activeTab === 'lookup' ? (
            <div className="space-y-12">
              <div className="bg-white rounded-[4rem] p-12 shadow-xl border border-slate-200">
                <div className="flex justify-between items-center mb-8">
                  <h3 className="text-3xl font-black uppercase italic tracking-tighter text-slate-900 leading-none">Registry Lookup</h3>
                  <button onClick={() => setIsScanning(true)} className="flex items-center gap-2 px-4 py-2 bg-brand-50 text-brand-600 rounded-xl font-black uppercase text-[10px] tracking-widest border border-brand-100 hover:bg-brand-100 transition-all">
                    <i className="fa-solid fa-qrcode"></i>
                    Scan Tag
                  </button>
                </div>
                <form onSubmit={handleSearch} className="relative">
                  <input 
                    type="text" 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Enter Bin Identifier (e.g. BIN-001)"
                    className="w-full py-8 px-10 bg-slate-50 border-4 border-slate-100 rounded-[2.5rem] text-xl font-black focus:border-brand-500 outline-none transition-all placeholder-slate-300 uppercase italic"
                  />
                  <button type="submit" className="absolute right-4 top-4 w-16 h-16 bg-brand-600 text-white rounded-3xl flex items-center justify-center text-xl shadow-xl hover:bg-brand-700 transition-all">
                    <i className="fa-solid fa-magnifying-glass"></i>
                  </button>
                </form>
              </div>

              {searchResult && (
                <div className="bg-white rounded-[4rem] p-12 shadow-2xl border-4 border-brand-500 animate-fade-in relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-8 opacity-5 text-8xl font-black italic select-none">NODE</div>
                  <div className="flex justify-between items-start mb-12">
                    <div>
                      <span className="text-[11px] font-black text-brand-600 uppercase tracking-widest block italic mb-2">Unit Status Hub</span>
                      <h4 className="text-5xl font-black uppercase italic tracking-tighter text-slate-900 leading-none">{searchResult.streetName}</h4>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-4 font-mono">ID_{searchResult.id}</p>
                    </div>
                    <div className="bg-brand-50 px-6 py-3 rounded-2xl border border-brand-100">
                      <span className="text-[9px] font-black text-brand-600 uppercase tracking-widest block italic mb-1">Sector</span>
                      <span className="text-sm font-black uppercase italic text-brand-900">{searchResult.district}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-8 mb-12">
                    <div className="bg-slate-50 p-8 rounded-[2.5rem] border border-slate-100 shadow-inner text-center">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-4 italic">Current Load</span>
                      <div className="relative w-32 h-32 mx-auto flex items-center justify-center">
                        <svg className="w-full h-full transform -rotate-90">
                          <circle cx="64" cy="64" r="58" stroke="#e2e8f0" strokeWidth="10" fill="transparent" />
                          <circle cx="64" cy="64" r="58" stroke={searchResult.fillLevel > 80 ? '#f43f5e' : '#8b5cf6'} strokeWidth="10" fill="transparent" strokeDasharray={364.4} strokeDashoffset={364.4 - (364.4 * searchResult.fillLevel) / 100} strokeLinecap="round" className="transition-all duration-1000" />
                        </svg>
                        <span className="absolute text-3xl font-black text-slate-900">{searchResult.fillLevel}%</span>
                      </div>
                    </div>
                    <div className="bg-slate-50 p-8 rounded-[2.5rem] border border-slate-100 shadow-inner flex flex-col justify-center">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-4 italic">Last Collection</span>
                      <p className="text-2xl font-black uppercase italic text-slate-900 tracking-tighter leading-none">
                        {searchResult.lastCollection ? new Date(searchResult.lastCollection).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'N/A'}
                      </p>
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mt-2 italic">Operational Sync</p>
                    </div>
                  </div>

                  <button 
                    onClick={() => { setCurrentBin(searchResult); setActiveTab('form'); }}
                    className="w-full py-8 bg-slate-900 text-white rounded-[2.5rem] font-black uppercase tracking-widest italic shadow-2xl hover:bg-black transition-all flex items-center justify-center gap-4"
                  >
                    <i className="fa-solid fa-bullhorn"></i>
                    Report Issue for this Unit
                  </button>
                </div>
              )}
            </div>
          ) : activeTab === 'tracking' ? (
            <div className="space-y-10">
              <div className="flex justify-between items-center px-6">
                <h3 className="text-2xl font-black uppercase italic tracking-tighter text-slate-900">Feedback Signals</h3>
                <span className="bg-brand-900 text-white px-4 py-1 rounded-full text-[9px] font-black uppercase tracking-widest italic">{myReports.length} Active</span>
              </div>
              {myReports.length === 0 ? (
                <div className="py-48 text-center space-y-10 opacity-20">
                  <i className="fa-solid fa-tower-observation text-9xl text-brand-300"></i>
                  <p className="text-lg font-black uppercase tracking-[0.6em]">Zero Active Signals</p>
                </div>
              ) : myReports.map(r => (
                <div key={r.id} className="bg-white border border-slate-200 rounded-[4rem] p-12 shadow-xl flex flex-col gap-10 relative overflow-hidden animate-fade-in">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-6">
                        <div className="w-16 h-16 bg-brand-50 border border-brand-100 rounded-3xl flex items-center justify-center text-brand-900 text-3xl"><i className="fa-solid fa-signal"></i></div>
                        <div>
                            <h4 className="font-black text-4xl uppercase italic tracking-tighter leading-none mb-1 text-slate-900">{r.type} <span className="text-brand-500">Alert</span></h4>
                            <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest italic font-mono">ID_{r.id.substring(0,8).toUpperCase()}</p>
                        </div>
                    </div>
                    <span className={`px-8 py-3 rounded-full text-[11px] font-black uppercase tracking-widest shadow-sm ${r.status === 'in-progress' ? 'bg-amber-50 text-amber-600' : 'bg-brand-50 text-brand-600'} animate-pulse`}>
                      {r.status === 'in-progress' ? 'Rectifying' : 'Operational'}
                    </span>
                  </div>
                  <div className="bg-slate-50 p-10 rounded-[2.5rem] border border-slate-100 shadow-inner flex flex-col gap-2">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest italic">Unit Sector Registry</p>
                        <p className="text-3xl font-black uppercase italic text-slate-900 tracking-tighter leading-none">{r.binStreetName}</p>
                  </div>
                  <div className="flex items-center gap-4 px-2">
                     <i className={`fa-solid ${r.status === 'in-progress' ? 'fa-screwdriver-wrench text-amber-500' : 'fa-clock text-slate-300'}`}></i>
                     <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{r.status === 'in-progress' ? 'Operational team is investigating...' : 'Awaiting Rectification Logic...'}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : activeTab === 'profile' ? (
            <div className="space-y-12">
              <div className="bg-white rounded-[4rem] p-12 shadow-xl border border-slate-200">
                <div className="flex items-center gap-6 mb-10">
                  <div className="w-20 h-20 bg-brand-50 rounded-3xl flex items-center justify-center text-brand-600 text-3xl shadow-inner border border-brand-100">
                    <i className="fa-solid fa-user-gear"></i>
                  </div>
                  <div>
                    <h3 className="text-3xl font-black uppercase italic tracking-tighter text-slate-900 leading-none">Account Settings</h3>
                    <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mt-2 italic">Manage your digital identity</p>
                  </div>
                </div>

                <div className="space-y-10">
                  <div className="p-8 bg-slate-50 rounded-[2.5rem] border border-slate-100 shadow-inner">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2 italic">Active Registry Email</span>
                    <p className="text-xl font-black text-slate-900 italic">{user?.email}</p>
                  </div>

                  <form onSubmit={handleUpdatePassword} className="space-y-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4 italic">New Password</label>
                      <input 
                        type="password" 
                        value={newPassword} 
                        onChange={(e) => setNewPassword(e.target.value)}
                        className="w-full bg-white border-4 border-slate-100 rounded-[2rem] p-6 text-sm focus:border-brand-500 outline-none transition-all shadow-inner" 
                        placeholder="Enter new password" 
                        required 
                      />
                    </div>

                    {passwordStatus && (
                      <div className={`p-4 rounded-xl text-[10px] font-black uppercase text-center italic ${passwordStatus.type === 'success' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-rose-50 text-rose-600 border border-rose-100'}`}>
                        {passwordStatus.msg}
                      </div>
                    )}

                    <button 
                      disabled={passwordLoading} 
                      type="submit" 
                      className="w-full py-6 bg-slate-900 text-white rounded-[2rem] font-black uppercase text-xs tracking-widest shadow-xl transition-all active:scale-95 italic flex items-center justify-center gap-3"
                    >
                      {passwordLoading ? <i className="fa-solid fa-circle-notch animate-spin"></i> : <i className="fa-solid fa-key"></i>}
                      Update Security Key
                    </button>
                  </form>

                  <button 
                    onClick={() => { if (window.confirm("Confirm session termination?")) onLogout(); }}
                    className="w-full py-6 border-4 border-rose-100 text-rose-600 rounded-[2rem] font-black uppercase text-xs tracking-widest hover:bg-rose-50 transition-all italic flex items-center justify-center gap-3"
                  >
                    <i className="fa-solid fa-power-off"></i>
                    Terminate Session
                  </button>
                </div>
              </div>
              
              <div className="bg-brand-900 rounded-[3rem] p-10 text-white shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-10 text-6xl font-black italic select-none">PII</div>
                <h4 className="text-xl font-black uppercase italic tracking-tight mb-4">Privacy Notice</h4>
                <p className="text-brand-200 text-xs font-bold leading-relaxed uppercase tracking-tight">
                  Your data is encrypted and stored within the Neuro_Core infrastructure. Password updates are processed immediately across all regional nodes.
                </p>
              </div>
            </div>
          ) : activeTab === 'survey' ? (
            <div className="space-y-12">
              <div className="bg-white rounded-[4rem] p-12 shadow-xl border border-slate-200 text-center">
                <div className="w-24 h-24 bg-brand-50 rounded-3xl flex items-center justify-center text-brand-600 text-4xl mx-auto mb-10 shadow-inner border border-brand-100">
                  <i className="fa-solid fa-qrcode"></i>
                </div>
                <h3 className="text-3xl font-black uppercase italic tracking-tighter text-slate-900 leading-none mb-4">Public Survey QR</h3>
                <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-12 italic">Scan to provide general feedback via Google Forms</p>
                
                <div className="bg-slate-50 p-12 rounded-[3rem] border-4 border-slate-100 shadow-inner inline-block mb-12">
                  <img 
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(surveyUrl)}`} 
                    alt="Survey QR Code"
                    className="w-64 h-64 mx-auto rounded-2xl shadow-2xl border-8 border-white"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="space-y-6">
                  <a 
                    href={surveyUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-full py-8 bg-brand-900 text-white rounded-[2.5rem] font-black uppercase text-sm tracking-[0.3em] shadow-4xl flex items-center justify-center gap-4 hover:bg-brand-800 transition-all italic"
                  >
                    <i className="fa-solid fa-arrow-up-right-from-square"></i>
                    Open Survey Link
                  </a>
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest italic">
                    External Link to Google Forms Infrastructure
                  </p>
                </div>
              </div>

              <div className="bg-slate-900 rounded-[3rem] p-10 text-white shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-10 text-6xl font-black italic select-none">SURVEY</div>
                <h4 className="text-xl font-black uppercase italic tracking-tight mb-4">Operational Insight</h4>
                <p className="text-slate-400 text-xs font-bold leading-relaxed uppercase tracking-tight">
                  This survey is used to gather high-level regional data for municipal planning and service optimization.
                </p>
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
};
