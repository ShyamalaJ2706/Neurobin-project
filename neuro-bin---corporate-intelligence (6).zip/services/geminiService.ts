
import { GoogleGenAI, Type } from "@google/genai";
import { Bin, RouteSuggestion } from "../types";

/**
 * Optimizes the collection route for bins that are critically full using Gemini 3 Pro reasoning.
 */
export const getRouteOptimization = async (bins: Bin[]): Promise<RouteSuggestion> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const criticalBins = bins.filter(b => b.fillLevel > 70);
  
  const binDataForModel = criticalBins.map(b => ({
    id: b.id,
    location: b.locationName,
    fill: b.fillLevel,
    district: b.district,
    coords: b.coordinates
  }));

  if (binDataForModel.length === 0) {
    return {
      optimizedOrder: [],
      estimatedDistanceKm: 0,
      reasoning: "No bins are currently critical enough to require an urgent special route.",
      priorityBins: []
    };
  }

  const prompt = `
    You are an expert waste management logistician AI.
    I have a fleet of waste trucks operating in an industrial regional sector.
    Here is a list of bins that are currently critically full (>70%) with their Latitude/Longitude coordinates:
    ${JSON.stringify(binDataForModel)}

    Please optimize a collection route for these bins based on their spatial distribution. 
    Consider that bins in the same 'district' or sector are likely closer together.
    Use the Lat/Lng to estimate a logical path.
    
    Provide:
    1. An optimized order of bin IDs to visit.
    2. An estimated distance in KM.
    3. A brief reasoning for the route strategy.
    4. The list of priority bin IDs.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 32768 },
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            optimizedOrder: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            estimatedDistanceKm: { type: Type.NUMBER },
            reasoning: { type: Type.STRING },
            priorityBins: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text.trim()) as RouteSuggestion;

  } catch (error) {
    console.error("Gemini optimization failed:", error);
    throw error;
  }
};

/**
 * Generates executive summaries and insights for waste management operations using Gemini 3 Flash.
 */
export const getGeneralInsights = async (bins: Bin[]): Promise<string> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const stats = {
        total: bins.length,
        avgFill: Math.round(bins.reduce((acc, b) => acc + b.fillLevel, 0) / (bins.length || 1)),
        critical: bins.filter(b => b.fillLevel > 80).length,
        districts: [...new Set(bins.map(b => b.district))]
    };

    const prompt = `
        Analyze this waste management corporation status for the current regional sector:
        ${JSON.stringify(stats)}
        
        Provide a concise, 2-sentence executive summary of the operational status and immediate logistical recommendations.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: prompt,
        });
        return response.text || "Analysis unavailable.";
    } catch (e) {
        return "System analysis temporarily unavailable.";
    }
}
