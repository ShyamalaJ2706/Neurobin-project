
import { Coordinates } from '../types';

// Open Source Routing Machine (OSRM) - Free public demo server
// In a production corporate app, you would host your own OSRM instance or use Google Directions API
const OSRM_API_BASE = 'https://router.project-osrm.org/route/v1/driving';

export interface RouteResult {
  coordinates: Coordinates[];
  distance: number; // meters
  duration: number; // seconds
}

export const getRealRoadRoute = async (start: Coordinates, end: Coordinates): Promise<RouteResult | null> => {
  try {
    // OSRM expects "lng,lat" (Longitude first)
    const url = `${OSRM_API_BASE}/${start.lng},${start.lat};${end.lng},${end.lat}?overview=full&geometries=geojson`;
    
    const response = await fetch(url);
    const data = await response.json();

    if (data.code !== 'Ok' || !data.routes || data.routes.length === 0) {
      console.error("OSRM Routing failed:", data);
      return null;
    }

    const route = data.routes[0];
    
    // Convert GeoJSON [lng, lat] to Leaflet [lat, lng]
    const pathCoordinates: Coordinates[] = route.geometry.coordinates.map((coord: number[]) => ({
      lat: coord[1],
      lng: coord[0]
    }));

    return {
      coordinates: pathCoordinates,
      distance: route.distance,
      duration: route.duration
    };

  } catch (error) {
    console.error("Failed to fetch route:", error);
    return null;
  }
};
