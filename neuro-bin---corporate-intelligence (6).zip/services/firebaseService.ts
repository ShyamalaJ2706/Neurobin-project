
import { initializeApp, getApps, getApp } from "firebase/app";
import { 
  getDatabase, ref, onValue, set, get, push, update, limitToLast, query, remove
} from "firebase/database";
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updatePassword as firebaseUpdatePassword
} from "firebase/auth";
import { Bin, User, Coordinates, BinStatus, CollectionRecord } from "../types";
import { INITIAL_BINS } from "../constants";

const firebaseConfig = {
  apiKey: "AIzaSyB1PkMsOdRrFkSP8suI5vhDaeGm0c3KKYs",
  authDomain: "neurobin-a9220.firebaseapp.com",
  databaseURL: "https://neurobin-a9220-default-rtdb.firebaseio.com",
  projectId: "neurobin-a9220",
  storageBucket: "neurobin-a9220.firebasestorage.app",
  messagingSenderId: "106261180834",
  appId: "1:106261180834:web:920cfbcc6cb95072cd82fb",
  measurementId: "G-GNMD917RBP"
};

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const db = getDatabase(app);
export const auth = getAuth(app);

export const resetPassword = async (email: string) => {
  try {
    const cleanEmail = email.toLowerCase().trim();
    // Rely on Firebase Auth directly to handle the reset
    await sendPasswordResetEmail(auth, cleanEmail);
  } catch (error: any) {
    console.error("Reset Password Error:", error.code, error.message);
    if (error.code === 'auth/user-not-found') {
      throw new Error("This email is not registered. Please create an account first.");
    } else if (error.code === 'auth/invalid-email') {
      throw new Error("Invalid email format.");
    }
    throw new Error("Failed to send reset link. Please try again in a moment.");
  }
};

export const updatePassword = async (newPassword: string) => {
  const user = auth.currentUser;
  if (!user) throw new Error("No user logged in.");
  await firebaseUpdatePassword(user, newPassword);
};

const getUniversalKey = (id: string) => {
  if (!id) return "";
  return id.toLowerCase().trim().replace(/[@.#$[\]/]/g, "_");
};

export const updateBinProperty = async (binId: string, property: string, value: any) => {
  const binRef = ref(db, `bins/${binId}`);
  return update(binRef, { [property]: value });
};

export const logCollection = async (binId: string, operator: string) => {
  const binRef = ref(db, `bins/${binId}`);
  const snapshot = await get(binRef);
  const binData = snapshot.val() as Bin;
  
  const newRecord: CollectionRecord = {
    timestamp: new Date().toISOString(),
    operator,
    fillLevelAtCollection: binData.fillLevel // Capture current load for history
  };

  const history = binData.history ? [...binData.history, newRecord] : [newRecord];
  
  await update(binRef, {
    history,
    fillLevel: 0,
    sensorReading: binData.depth || 200,
    lastCollection: newRecord.timestamp,
    status: BinStatus.NORMAL
  });

  // Clean up mission
  const missionRef = ref(db, `fleet/active_missions/${binId}`);
  await remove(missionRef);
};

export const getAddressFromCoords = async (lat: number, lng: number): Promise<string> => {
  try {
    const res = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`);
    const data = await res.json();
    return data.display_name || "Unknown Location";
  } catch {
    return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
  }
};

export const loginUser = async (email: string, password: string): Promise<User | null> => {
  const inputEmail = email.toLowerCase().trim();
  try {
    const userCredential = await signInWithEmailAndPassword(auth, inputEmail, password);
    if (userCredential.user) {
      const primaryKey = getUniversalKey(inputEmail);
      const snapshot = await get(ref(db, `users/${primaryKey}`));
      return snapshot.val() || { username: primaryKey, role: 'admin', email: inputEmail };
    }
    return null;
  } catch (error: any) {
    console.error("Login Error:", error.code, error.message);
    if (error.code === 'auth/user-not-found') {
      throw new Error("No account found with this email. Please register first.");
    } else if (error.code === 'auth/wrong-password') {
      throw new Error("Incorrect password. Please try again.");
    } else if (error.code === 'auth/too-many-requests') {
      throw new Error("Too many failed attempts. Please try again later or reset your password.");
    } else if (error.code === 'auth/invalid-email') {
      throw new Error("Invalid email format.");
    }
    throw new Error("Authentication failed. Please check your credentials.");
  }
};

export const startFleetMission = async (binId: string, streetName: string, driverName: string, eta?: string, distance?: string) => {
  try {
    const missionRef = ref(db, `fleet/active_missions/${binId}`);
    await set(missionRef, {
      driver: driverName,
      binId,
      streetName,
      startTime: new Date().toISOString(),
      status: 'Assigned',
      estimatedDuration: eta || '20 min',
      estimatedDistance: distance || 'Calculated'
    });
  } catch (e) {
    console.warn("Mission Sync Failed:", e);
    return true;
  }
};

export const subscribeToMissions = (callback: (data: any) => void) => {
  const missionsRef = ref(db, 'fleet/active_missions');
  return onValue(missionsRef, (snapshot) => {
    callback(snapshot.val() || {});
  });
};

export const subscribeToRawTelemetry = (callback: (data: any) => void) => {
  const rawRef = query(ref(db, 'waste_bins'), limitToLast(1));
  return onValue(rawRef, (snapshot) => {
    const val = snapshot.val();
    if (val) {
      const keys = Object.keys(val);
      const latestData = val[keys[keys.length - 1]];
      callback(latestData);
    }
  });
};

export const subscribeToBinTelemetry = (callback: (data: Bin[]) => void) => {
  const binsRef = ref(db, 'bins');
  return onValue(binsRef, (snapshot) => {
    const val = snapshot.val();
    callback(val ? Object.values(val) : INITIAL_BINS);
  });
};

export const subscribeToReports = (callback: (data: any) => void) => {
  const reportsRef = ref(db, 'reports');
  return onValue(reportsRef, (snapshot) => {
    callback(snapshot.val() || {});
  });
};

export const subscribeToComplaints = (callback: (data: any) => void) => {
  const complaintsRef = ref(db, 'Complaint');
  return onValue(complaintsRef, (snapshot) => {
    callback(snapshot.val() || {});
  });
};

export const submitReport = async (binId: string, type: string, message: string, userLocation?: Coordinates, locationName?: string, binStreetName?: string, userId?: string) => {
  const reportsRef = ref(db, 'reports');
  const newReportRef = push(reportsRef);
  await set(newReportRef, {
    binId, type, message, timestamp: new Date().toISOString(), status: 'pending', userLocation, locationName, binStreetName, userId
  });
  return newReportRef.key;
};

export const resolveReport = async (reportId: string, staffName: string, note: string, status: 'resolved' | 'in-progress' = 'resolved') => {
  const reportRef = ref(db, `reports/${reportId}`);
  await update(reportRef, { 
    status, rectifiedBy: staffName, rectifiedAt: new Date().toISOString(), resolutionNote: note 
  });
  return true;
};

export const resolveComplaint = async (complaintId: string, staffName: string, note: string, status: 'resolved' | 'in-progress' = 'resolved') => {
  const complaintRef = ref(db, `Complaint/${complaintId}`);
  await update(complaintRef, { 
    status, rectifiedBy: staffName, rectifiedAt: new Date().toISOString(), resolutionNote: note 
  });
  return true;
};

export const initializeBinsInFirebase = async (initialBins: Bin[]) => {
  try {
    const binsRef = ref(db, 'bins');
    const snapshot = await get(binsRef);
    if (!snapshot.exists()) {
      const binsMap: Record<string, Bin> = {};
      initialBins.forEach(bin => { binsMap[bin.id] = bin; });
      await set(binsRef, binsMap);
    }
  } catch (e) {
    console.warn("Initial setup skipped.");
  }
};

export const signupUser = async (user: User) => {
  const email = user.email?.toLowerCase().trim();
  if (!email) return;
  const primaryKey = getUniversalKey(email);
  
  try {
    await createUserWithEmailAndPassword(auth, email, user.password || '123456');
  } catch (error: any) {
    if (error.code === 'auth/email-already-in-use') {
      // If Auth exists, ensure DB record is created
      await set(ref(db, `users/${primaryKey}`), { ...user, email, username: primaryKey, registeredAt: new Date().toISOString() });
      return;
    }
    throw error;
  }
  
  await set(ref(db, `users/${primaryKey}`), { ...user, email, username: primaryKey, registeredAt: new Date().toISOString() });
};

export const simulateHardwarePacket = async (b1Val: number, b2Val: number) => {
  const rawRef = ref(db, 'waste_bins');
  await push(rawRef, {
    timestamp: new Date().toISOString(),
    distance1_cm: b1Val,
    distance2_cm: b2Val,
    lat: 13.067677,
    lng: 80.216335
  });
};
