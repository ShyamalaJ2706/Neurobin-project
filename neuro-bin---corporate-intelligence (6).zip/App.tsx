
import React, { useState, useEffect, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { MapVisualizer } from './components/MapVisualizer';
import { LoginPage } from './components/LoginPage';
import { SplashScreen } from './components/SplashScreen';
import { BinCard } from './components/BinCard';
import { AnalyticsHub } from './components/AnalyticsHub';
import { LandingPage } from './components/LandingPage';
import { CitizenPortal } from './components/CitizenPortal';
import { QRScanner } from './components/QRScanner';
import { INITIAL_BINS } from './constants';
import { Bin, BinStatus, User, Coordinates, CitizenReport } from './types';
import { getRealRoadRoute } from './services/routingService';
import { 
  subscribeToBinTelemetry, 
  subscribeToReports, 
  initializeBinsInFirebase,
  subscribeToRawTelemetry,
  resolveReport,
  resolveComplaint,
  getAddressFromCoords,
  startFleetMission,
  subscribeToMissions,
  updateBinProperty,
  logCollection,
  subscribeToComplaints,
  db
} from './services/firebaseService';
import { ref, update } from 'firebase/database';

const getCurrentPosition = (): Promise<GeolocationPosition> => {
  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(resolve, reject, { 
      enableHighAccuracy: true, 
      timeout: 10000, 
      maximumAge: 0 
    });
  });
};

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('neuro_current_user');
      return saved ? JSON.parse(saved) : null;
    } catch { return null; }
  });
  
  const [appMode, setAppMode] = useState<'landing' | 'staff' | 'citizen'>(() => {
    return 'staff';
  });

  const [view, setView] = useState<'dashboard' | 'map' | 'bins' | 'fleet' | 'analytics' | 'report'>('dashboard');
  const [mapCenter, setMapCenter] = useState<Coordinates | null>(null);
  const [bins, setBins] = useState<Bin[]>(INITIAL_BINS);
  const [reports, setReports] = useState<CitizenReport[]>([]);
  const [activeMissions, setActiveMissions] = useState<any>({});
  const [userLocation, setUserLocation] = useState<Coordinates | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  
  const [dispatchBin, setDispatchBin] = useState<Bin | null>(null);
  const [driverName, setDriverName] = useState('');
  const [isDispatching, setIsDispatching] = useState(false);
  
  const [routePath, setRoutePath] = useState<Coordinates[]>([]);
  const [routeInfo, setRouteInfo] = useState<{ distance: string, duration: string, targetId?: string, streetName?: string } | null>(null);

  const [isHardwareLinked, setIsHardwareLinked] = useState(false);
  const [reportBinId, setReportBinId] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [showSplash, setShowSplash] = useState(true);

  const [surveyUrl, setSurveyUrl] = useState(() => {
    return localStorage.getItem('neuro_survey_url') || 'https://docs.google.com/forms/d/e/1FAIpQLSdssVVXoQ-eNz4_tRtmsltZothNXT-1psES0bFivaOOk3F0Mg/viewform?usp=header';
  });
  const [showSurveyConfig, setShowSurveyConfig] = useState(false);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const binId = urlParams.get('reportBinId');
    if (binId) {
      setReportBinId(binId);
      setAppMode('citizen');
      // Clean up URL without refreshing
      window.history.replaceState({}, document.title, "/");
    }
  }, []);
  const [lastPacketDate, setLastPacketDate] = useState<Date | null>(null);
  const [simulatedTruckPositions, setSimulatedTruckPositions] = useState<Record<string, { address: string, progress: number, currentCoords?: Coordinates }>>({});

  // Resolution State
  const [resolvingReportId, setResolvingReportId] = useState<string | null>(null);
  const [resolutionNote, setResolutionNote] = useState('');
  const [resolutionStatus, setResolutionStatus] = useState<'resolved' | 'in-progress'>('resolved');

  useEffect(() => {
    let watchId: number;
    
    const startTracking = () => {
      watchId = navigator.geolocation.watchPosition(
        (pos) => {
          setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        },
        (err) => {
          console.warn("GPS Watch Error:", err);
          // Fallback to static if watch fails
          if (!userLocation) setUserLocation({ lat: 13.067677, lng: 80.216335 });
        },
        { enableHighAccuracy: true, maximumAge: 1000, timeout: 5000 }
      );
    };

    startTracking();
    return () => {
      if (watchId) navigator.geolocation.clearWatch(watchId);
    };
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      if (lastPacketDate) {
        const diff = Date.now() - lastPacketDate.getTime();
        if (diff > 120000) setIsHardwareLinked(false);
      } else {
        setIsHardwareLinked(false);
      }
    }, 10000);
    return () => clearInterval(interval);
  }, [lastPacketDate]);

  // Main Mission Simulation Loop
  useEffect(() => {
    const interval = setInterval(async () => {
      const missions = Object.values(activeMissions);
      if (missions.length === 0) return;
      
      const newSims = { ...simulatedTruckPositions };
      
      for (const m of missions as any) {
        if (!newSims[m.binId]) {
           const addr = await getAddressFromCoords(userLocation?.lat || 13, userLocation?.lng || 80);
           newSims[m.binId] = { 
             address: addr.split(',').slice(0, 2).join(','), 
             progress: 0,
             currentCoords: userLocation || { lat: 13, lng: 80 }
           };
        }

        if (m.status === 'En Route') {
          const currentProgress = newSims[m.binId]?.progress || 0;
          
          if (currentProgress < 100) {
            const durationParts = m.estimatedDuration?.match(/\d+/g);
            let totalSeconds = 600;
            if (durationParts) {
              const mins = parseInt(durationParts[0]);
              const secs = durationParts[1] ? parseInt(durationParts[1]) : 0;
              totalSeconds = (mins * 60) + secs;
            }

            // Progress simulation based on time for the progress bar, 
            // but we no longer simulate coordinates for the map
            const increment = (1.0 / totalSeconds) * 100; 
            const nextProgress = Math.min(100, currentProgress + increment);
            
            const targetBin = bins.find(b => b.id === m.binId);
            if (targetBin && userLocation) {
                let newAddr = newSims[m.binId]?.address || "Determining Sector...";
                if (Math.floor(nextProgress / 10) > Math.floor(currentProgress / 10)) {
                   const addr = await getAddressFromCoords(userLocation.lat, userLocation.lng);
                   newAddr = addr.split(',').slice(0, 2).join(',');
                }

                newSims[m.binId] = { 
                  address: newAddr, 
                  progress: nextProgress
                };

                if (routeInfo?.targetId === m.binId) {
                  const remainingSecs = Math.max(0, Math.round(totalSeconds * (1 - nextProgress / 100)));
                  const rMins = Math.floor(remainingSecs / 60);
                  const rSecs = remainingSecs % 60;
                  setRouteInfo(prev => prev ? { ...prev, duration: `${rMins}M ${rSecs}S` } : null);
                }
            }

            if (nextProgress >= 100) {
                await handleCompleteCollection(m.binId, m.driver);
                const missionRef = ref(db, `fleet/active_missions/${m.binId}`);
                await update(missionRef, { status: 'Arrived' });
            }
          }
        }
      }
      setSimulatedTruckPositions(newSims);
    }, 1000); // 1s loop for smoother tracking
    return () => clearInterval(interval);
  }, [activeMissions, bins, userLocation, simulatedTruckPositions, routeInfo, routePath]);

  useEffect(() => {
    initializeBinsInFirebase(INITIAL_BINS);
    const unsubRaw = subscribeToRawTelemetry(async (raw) => {
      if (raw) {
        const now = new Date();
        setIsHardwareLinked(true);
        setLastPacketDate(now);
        const lat = raw.latitude ?? raw.lat;
        const lng = raw.longitude ?? raw.lng;
        const hardwareCoords: Coordinates | null = (lat !== undefined && lng !== undefined) 
          ? { lat: parseFloat(lat), lng: parseFloat(lng) } 
          : null;
        setBins(prev => prev.map(bin => {
          let rawVal = undefined;
          if (bin.id === 'BIN-001') rawVal = raw.distance1_cm ?? raw.distance1;
          else if (bin.id === 'BIN-002') rawVal = raw.distance2_cm ?? raw.distance2;
          if (rawVal === undefined) return bin;
          const depth = bin.depth || 200;
          const level = Math.max(0, Math.min(100, Math.round(((depth - rawVal) / depth) * 100)));
          return { ...bin, fillLevel: level, sensorReading: Number(parseFloat(rawVal).toFixed(2)), lastHardwareUpdate: now.toISOString(), status: level > 85 ? BinStatus.CRITICAL : level > 60 ? BinStatus.WARNING : BinStatus.NORMAL, coordinates: hardwareCoords || bin.coordinates };
        }));
      }
    });
    const unsubBins = subscribeToBinTelemetry((list) => setBins(prev => prev.map(p => { const match = list.find(s => s.id === p.id); return match ? { ...p, ...match } : p; })));
    const unsubMissions = subscribeToMissions(setActiveMissions);
    
    let rawReports: Record<string, any> = {};
    let rawComplaints: Record<string, any> = {};

    const updateMergedReports = () => {
      const reportList = Object.entries(rawReports).map(([id, v]) => ({ 
        id, 
        ...v, 
        source: 'report' 
      })) as CitizenReport[];
      
      const complaintList = Object.entries(rawComplaints).map(([id, v]) => ({ 
        id, 
        binId: v.name || 'EXTERNAL',
        binStreetName: v.name || 'Public Query',
        type: 'other',
        message: `${v.name} (${v.contact}): ${v.query}`,
        timestamp: v.timestamp || new Date().toISOString(), // Fallback if no timestamp
        status: (v.status || 'pending').toLowerCase(),
        userId: v.email,
        source: 'complaint'
      })) as CitizenReport[];

      const combined = [...reportList, ...complaintList].filter(r => {
        const name = (r.binStreetName || '').toLowerCase();
        return !name.includes('main bazaar') && !name.includes('gst road');
      });
      setReports(combined.sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
    };

    const unsubReports = subscribeToReports((rl) => {
       rawReports = rl || {};
       updateMergedReports();
    });

    const unsubComplaints = subscribeToComplaints((cl) => {
       rawComplaints = cl || {};
       updateMergedReports();
    });

    return () => { unsubRaw(); unsubBins(); unsubMissions(); unsubReports(); unsubComplaints(); };
  }, []);

  const handleUpdateBinDepth = async (binId: string, newDepth: number) => {
    await updateBinProperty(binId, 'depth', newDepth);
    setBins(prev => prev.map(b => b.id === binId ? { ...b, depth: newDepth } : b));
  };

  const handleStartDispatch = async () => {
    if (!driverName) { alert("Enter Operator Initials."); return; }
    setIsDispatching(true);
    const targetBin = dispatchBin!;
    try {
      let origin: Coordinates;
      try {
        const pos = await getCurrentPosition();
        origin = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setUserLocation(origin);
      } catch { origin = userLocation || { lat: 13.067677, lng: 80.216335 }; }
      
      const result = await getRealRoadRoute(origin, targetBin.coordinates);
      let calculatedEta = 'Calculated...';
      let calculatedDist = 'Calculated...';
      if (result) {
        const mins = Math.floor(result.duration / 60);
        const secs = Math.round(result.duration % 60);
        calculatedEta = `${mins} MIN ${secs} SEC`;
        calculatedDist = `${(result.distance / 1000).toFixed(1)} KM`;
        setRoutePath(result.coordinates);
      }
      setRouteInfo({ distance: calculatedDist, duration: calculatedEta, targetId: targetBin.id, streetName: targetBin.streetName });
      await startFleetMission(targetBin.id, targetBin.streetName, driverName, calculatedEta, calculatedDist);
      setDispatchBin(null);
      setDriverName('');
      setView('fleet');
    } catch { alert("Route failed."); } finally { setIsDispatching(false); }
  };

  const handleMissionGo = async (binId: string) => {
    const missionRef = ref(db, `fleet/active_missions/${binId}`);
    await update(missionRef, { status: 'En Route' });
    setView('map'); // AUTOMATIC REDIRECT: Once mission starts, go to map view immediately
  };

  const handleCompleteCollection = async (binId: string, driver: string) => {
    await logCollection(binId, driver);
    if (routeInfo?.targetId === binId) {
      setRouteInfo(null);
      setRoutePath([]);
    }
  };

  const handleFinalizeResolution = async () => {
    if (!resolvingReportId) return;
    const report = reports.find(r => r.id === resolvingReportId);
    if (report?.source === 'complaint') {
      await resolveComplaint(resolvingReportId, currentUser?.username || 'Staff', resolutionNote || 'Complaint updated via standard operational cleanup.', resolutionStatus);
    } else {
      await resolveReport(resolvingReportId, currentUser?.username || 'Staff', resolutionNote || 'Issue updated via standard operational cleanup.', resolutionStatus);
    }
    setResolvingReportId(null);
    setResolutionNote('');
    setResolutionStatus('resolved');
  };

  const handleLogout = () => {
    localStorage.removeItem('neuro_current_user');
    setCurrentUser(null);
    setAppMode('staff');
  };

  // Dynamic Route Recalculation
  useEffect(() => {
    if (!userLocation || !routeInfo?.targetId) return;

    const targetBin = bins.find(b => b.id === routeInfo.targetId);
    if (!targetBin) return;

    const recalculateRoute = async () => {
      try {
        const result = await getRealRoadRoute(userLocation, targetBin.coordinates);
        if (result) {
          const mins = Math.floor(result.duration / 60);
          const secs = Math.round(result.duration % 60);
          const calculatedEta = `${mins} MIN ${secs} SEC`;
          const calculatedDist = `${(result.distance / 1000).toFixed(1)} KM`;
          
          setRoutePath(result.coordinates);
          setRouteInfo(prev => prev ? { 
            ...prev, 
            distance: calculatedDist, 
            duration: calculatedEta 
          } : null);
        }
      } catch (e) {
        console.warn("Route recalculation failed:", e);
      }
    };

    // Recalculate if we move significantly (approx 50m) or every 30s
    recalculateRoute();
    const interval = setInterval(recalculateRoute, 30000);
    return () => clearInterval(interval);
  }, [userLocation?.lat, userLocation?.lng, routeInfo?.targetId]);

  const activeMissionId = routeInfo?.targetId;
  const currentTruckCoords = userLocation;

  const handleSplashComplete = useCallback(() => {
    setShowSplash(false);
  }, []);

  if (showSplash) return <SplashScreen onComplete={handleSplashComplete} />;

  if (appMode === 'citizen') {
    if (!currentUser) {
      return (
        <LoginPage 
          onLogin={(u) => { setCurrentUser(u); setAppMode('citizen'); }} 
          onRegister={(u) => { setCurrentUser(u); setAppMode('citizen'); }} 
          defaultRole="citizen"
        />
      );
    }
    return (
      <CitizenPortal 
        bin={bins.find(b => b.id === reportBinId) || null} 
        bins={bins} 
        user={currentUser}
        onLogin={setCurrentUser}
        onRegister={setCurrentUser}
        onLogout={() => setCurrentUser(null)}
        onBackToLanding={() => {}}
        surveyUrl={surveyUrl}
      />
    );
  }
  if (!currentUser && appMode === 'staff') return <LoginPage onLogin={(u) => { setCurrentUser(u); setAppMode('staff'); }} onRegister={setCurrentUser as any} />;
  if (appMode === 'landing') return <div className="min-h-screen bg-brand-900 flex items-center justify-center"><i className="fa-solid fa-circle-notch animate-spin text-white text-4xl"></i></div>;

  return (
    <div className="flex h-screen bg-brand-50 text-brand-900 overflow-hidden font-sans">
      <Sidebar currentView={view} setView={setView} user={currentUser!} onLogout={handleLogout} isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} onOpenScanner={() => setIsScanning(true)} />
      <main className="flex-1 flex flex-col relative overflow-hidden bg-brand-100/20">
        {isScanning && (
          <QRScanner 
            bins={bins} 
            onScan={(id) => {
              const found = bins.find(b => b.id.toUpperCase() === id.toUpperCase());
              if (found) {
                setMapCenter(found.coordinates);
                setView('dashboard');
                setIsScanning(false);
              } else {
                alert(`Asset ID [${id}] not registered in local registry.`);
              }
            }}
            onClose={() => setIsScanning(false)}
          />
        )}
        <header className="h-14 bg-white border-b border-brand-200 flex items-center justify-between px-6 shrink-0 z-30 shadow-sm">
          <div className="flex items-center gap-4">
             <div className={`w-2 h-2 rounded-full ${isHardwareLinked ? 'bg-emerald-500 shadow-[0_0_8px_#10b981]' : 'bg-rose-500 shadow-[0_0_8px_#f43f5e]'} animate-pulse`}></div>
             <div><h2 className="text-[10px] font-black text-brand-900 uppercase italic tracking-tighter leading-none">{view}</h2><p className="text-[7px] font-black text-brand-400 uppercase tracking-widest mt-0.5">{isHardwareLinked ? 'Uplink Synced' : 'LINK INTERRUPTED'}</p></div>
          </div>
          <div className="flex items-center gap-4">
            {view === 'dashboard' && (
              <button 
                onClick={() => setShowSurveyConfig(true)}
                className="flex items-center gap-2 px-4 py-1.5 bg-brand-50 text-brand-600 rounded-lg font-black uppercase text-[8px] tracking-widest border border-brand-100 hover:bg-brand-100 transition-all"
              >
                <i className="fa-solid fa-link"></i>
                Survey Config
              </button>
            )}
            <div className={`px-4 py-1.5 rounded-lg shadow-sm flex items-center gap-2 border ${isHardwareLinked ? 'bg-brand-900 text-white border-brand-900' : 'bg-white text-slate-400 border-slate-200'}`}><i className={`fa-solid ${isHardwareLinked ? 'fa-satellite-dish' : 'fa-plug-circle-exclamation'} text-[8px]`}></i><span className="text-[8px] font-black uppercase tracking-widest italic">{isHardwareLinked ? 'ACTIVE' : 'NO FEED'}</span></div>
          </div>
        </header>

        <div className="flex-1 overflow-hidden relative">
          {view === 'dashboard' && (<div className="h-full overflow-y-auto p-2 md:p-4 custom-scroll"><div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-4 max-w-[1600px] mx-auto pb-16">{bins.map(bin => <BinCard key={bin.id} bin={bin} onDispatch={setDispatchBin} onUpdateDepth={handleUpdateBinDepth} />)}</div></div>)}
          {view === 'map' && <MapVisualizer bins={bins} onBinClick={() => {}} districtFilter="ALL" userLocation={currentTruckCoords} routePath={routePath} routeInfo={routeInfo} center={mapCenter} />}
          
          {view === 'fleet' && (
            <div className="h-full overflow-y-auto p-2 md:p-3 animate-fade-in custom-scroll">
              <div className="max-w-2xl mx-auto space-y-4 pb-16">
                <div className="flex items-center justify-between border-b border-brand-100 pb-2"><div><h3 className="text-lg font-black uppercase italic tracking-tighter text-brand-900 leading-none">Fleet Operations Hub</h3><p className="text-[6px] font-black text-brand-400 uppercase tracking-[0.5em] mt-0.5 italic">Regional Logistics Commander</p></div><div className="flex items-center gap-2"><div className="text-right"><span className="text-[6px] font-black text-brand-500 uppercase tracking-widest block mb-0.5">Asset Connectivity</span><span className="text-[8px] font-black text-brand-900 uppercase italic">Real-Time Sync</span></div><div className="w-1 h-1 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981] animate-pulse"></div></div></div>
                <div className="space-y-3">
                  {Object.values(activeMissions).length === 0 ? (<div className="py-8 text-center border-2 border-dashed border-brand-50 rounded-xl bg-white flex flex-col items-center justify-center space-y-3 shadow-inner"><div className="w-10 h-10 bg-brand-50 rounded-lg flex items-center justify-center text-brand-200 text-lg shadow-inner border border-brand-100"><i className="fa-solid fa-truck-ramp-box"></i></div><p className="text-brand-900 text-xs font-black uppercase tracking-tighter italic">Fleet Available for Deployment</p></div>) : (
                    Object.values(activeMissions).map((m: any) => {
                      const sim = simulatedTruckPositions[m.binId] || { address: "Locating Fix...", progress: 0 };
                      const isStandby = m.status === 'Assigned' || m.status === 'Standby';
                      const isArrived = m.status === 'Arrived';
                      return (
                        <div key={m.binId} className={`bg-white rounded-xl border border-brand-100 shadow-md flex flex-col gap-2 group relative overflow-hidden transition-all hover:shadow-lg border-l-4 ${isArrived ? 'border-l-emerald-500' : isStandby ? 'border-l-brand-200' : 'border-l-brand-500'} p-0.5`}>
                           <div className="flex items-center justify-between p-3 pb-0">
                              <div className="flex items-center gap-3"><div className={`w-8 h-8 ${isArrived ? 'bg-emerald-600' : isStandby ? 'bg-slate-900/5 text-slate-400' : 'bg-brand-900'} text-white rounded-lg flex items-center justify-center text-base transition-all shadow-md`}><i className={`fa-solid ${isArrived ? 'fa-location-dot' : isStandby ? 'fa-truck' : 'fa-truck-fast animate-pulse'}`}></i></div><div><span className="text-[6px] font-black text-brand-500 uppercase tracking-[0.4em] mb-0.5 block italic leading-none">Unit Commander</span><h4 className="text-base font-black uppercase italic tracking-tighter text-brand-900 leading-none">{m.driver}</h4></div></div>
                              <div className="text-right flex flex-col items-end gap-1.5"><div className="flex items-center gap-1"><span className={`w-1 h-1 rounded-full ${isArrived ? 'bg-emerald-500' : isStandby ? 'bg-slate-300' : 'bg-emerald-500 animate-pulse'}`}></span><span className="text-[7px] font-black text-brand-900 uppercase italic tracking-widest">{m.status}</span></div>{isStandby && (<button onClick={() => handleMissionGo(m.binId)} className="bg-brand-900 hover:bg-black text-white px-4 py-1.5 rounded-full text-[7px] font-black uppercase tracking-widest italic shadow-lg active:scale-95 transition-all flex items-center gap-1.5"><i className="fa-solid fa-play text-[8px]"></i> Initialize Start</button>)}{isArrived && (<button onClick={() => handleCompleteCollection(m.binId, m.driver)} className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-1.5 rounded-full text-[7px] font-black uppercase tracking-widest italic shadow-lg active:scale-95 transition-all flex items-center gap-1.5"><i className="fa-solid fa-check-double text-[8px]"></i> Log Collection</button>)}</div>
                           </div>
                           <div className="grid grid-cols-1 md:grid-cols-3 gap-2 px-3">
                              <div className="bg-brand-50 p-2 rounded-lg border border-brand-100 shadow-inner flex flex-col justify-center"><span className="text-[6px] font-black text-brand-400 uppercase tracking-widest block mb-0.5 italic">Vector Location</span><p className="text-[9px] font-black uppercase italic text-brand-900 tracking-tighter truncate">{sim.address}</p></div>
                              <div className="bg-brand-50 p-2 rounded-lg border border-brand-100 shadow-inner flex flex-col justify-center"><span className="text-[6px] font-black text-brand-400 uppercase tracking-widest block mb-0.5 italic">Target Sector</span><p className="text-[9px] font-black uppercase italic text-brand-900 tracking-tighter truncate">{m.streetName}</p></div>
                              <div className={`${isArrived ? 'bg-emerald-600' : isStandby ? 'bg-brand-800' : 'bg-brand-900 shadow-md'} p-2 rounded-lg flex justify-between items-center transition-colors`}><div className="text-left"><span className="text-[6px] font-black text-brand-400 uppercase tracking-widest block mb-0.5 italic">Tactical ETA</span><p className="text-base font-black text-white tracking-tighter italic leading-none">{isArrived ? 'REACHED' : m.estimatedDuration}</p></div><div className="w-6 h-6 rounded-lg bg-brand-500 flex items-center justify-center text-white text-xs shadow-[0_0_10px_#2563eb]"><i className="fa-solid fa-clock-rotate-left"></i></div></div>
                           </div>
                           <div className="px-3 pb-3"><div className="w-full bg-brand-50 h-1 rounded-full overflow-hidden border border-brand-100 shadow-inner"><div className={`h-full ${isArrived ? 'bg-emerald-500' : isStandby ? 'bg-brand-100' : 'bg-brand-500'} transition-all duration-1000 ease-linear shadow-[0_0_5px_currentColor]`} style={{ width: `${sim.progress}%` }}></div></div></div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          )}

          {view === 'report' && (
            <div className="h-full overflow-y-auto p-6 animate-fade-in custom-scroll">
              <div className="max-w-6xl mx-auto bg-white rounded-3xl border border-brand-200 shadow-xl overflow-hidden">
                <div className="p-6 border-b border-brand-50 bg-brand-50/50 flex justify-between items-center">
                  <h3 className="text-base font-black uppercase italic tracking-tighter">Incident Hub</h3>
                  <span className="bg-rose-500 text-white px-3 py-1 rounded-md text-[7px] font-black uppercase tracking-widest">{reports.length} ALERTS</span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead className="bg-brand-50/30 border-b border-brand-50">
                      <tr>
                        <th className="px-6 py-4 text-[7px] font-black uppercase text-brand-400 tracking-widest">Identifier</th>
                        <th className="px-6 py-4 text-[7px] font-black uppercase text-brand-400 tracking-widest">Sector</th>
                        <th className="px-6 py-4 text-[7px] font-black uppercase text-brand-400 tracking-widest">Type</th>
                        <th className="px-6 py-4 text-[7px] font-black uppercase text-brand-400 tracking-widest">Message</th>
                        <th className="px-6 py-4 text-[7px] font-black uppercase text-brand-400 tracking-widest">Status</th>
                        <th className="px-6 py-4 text-[7px] font-black uppercase text-brand-400 tracking-widest">Timestamp</th>
                        <th className="px-6 py-4 text-[7px] font-black uppercase text-brand-400 tracking-widest">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-brand-50 text-[9px]">
                      {reports.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="px-6 py-12 text-center text-brand-400 font-black uppercase italic tracking-widest">No active incidents detected</td>
                        </tr>
                      ) : (
                        reports.map(r => (
                          <tr key={r.id} className="hover:bg-brand-50/50 transition-colors">
                            <td className="px-6 py-4 font-mono font-black text-brand-900">#{r.id.substring(0,6).toUpperCase()}</td>
                            <td className="px-6 py-4 font-black uppercase italic tracking-tighter">{r.binStreetName}</td>
                            <td className="px-6 py-4">
                              <span className={`px-2 py-0.5 rounded-full text-[7px] font-black uppercase tracking-widest ${r.source === 'complaint' ? 'bg-indigo-50 text-indigo-600' : 'bg-rose-50 text-rose-600'}`}>
                                {r.source || 'report'}
                              </span>
                            </td>
                            <td className="px-6 py-4 font-black text-brand-600 italic max-w-xs truncate" title={r.message}>{r.message}</td>
                            <td className="px-6 py-4">
                              <span className={`px-2 py-0.5 rounded-full text-[7px] font-black uppercase tracking-widest ${r.status === 'resolved' ? 'bg-emerald-50 text-emerald-600' : r.status === 'in-progress' ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600'}`}>
                                {r.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 font-black text-brand-400 italic">{new Date(r.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</td>
                            <td className="px-6 py-4">
                              <button 
                                onClick={() => setResolvingReportId(r.id)}
                                className="bg-brand-900 hover:bg-black text-white px-3 py-1 rounded text-[7px] font-black uppercase tracking-widest italic transition-all active:scale-95"
                              >
                                Resolve
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {view === 'bins' && (<div className="h-full overflow-y-auto p-6 animate-fade-in custom-scroll"><div className="max-w-6xl mx-auto bg-white rounded-3xl border border-brand-200 shadow-xl overflow-hidden"><div className="p-6 border-b border-brand-50 bg-brand-50/50 flex justify-between items-center"><h3 className="text-base font-black uppercase italic tracking-tighter">Unit Registry Hub</h3><span className="bg-brand-900 text-white px-3 py-1 rounded-md text-[7px] font-black uppercase tracking-widest">{bins.length} NODES</span></div><div className="overflow-x-auto"><table className="w-full text-left"><thead className="bg-brand-50/30 border-b border-brand-50"><tr><th className="px-6 py-4 text-[7px] font-black uppercase text-brand-400 tracking-widest">Identifier</th><th className="px-6 py-4 text-[7px] font-black uppercase text-brand-400 tracking-widest">Sector</th><th className="px-6 py-4 text-[7px] font-black uppercase text-brand-400 tracking-widest">Load Status</th><th className="px-6 py-4 text-[7px] font-black uppercase text-brand-400 tracking-widest">Last Collection</th><th className="px-6 py-4 text-[7px] font-black uppercase text-brand-400 tracking-widest">Telemetry</th></tr></thead><tbody className="divide-y divide-brand-50 text-[9px]">{bins.map(b => (<tr key={b.id} className="hover:bg-brand-50/50 transition-colors"><td className="px-6 py-4 font-mono font-black text-brand-900">{b.id}</td><td className="px-6 py-4 font-black uppercase italic tracking-tighter">{b.streetName}</td><td className="px-6 py-4"><div className="flex items-center gap-2"><div className="w-12 h-1 bg-brand-100 rounded-full overflow-hidden"><div className={`h-full ${b.fillLevel > 80 ? 'bg-rose-500' : 'bg-brand-500'}`} style={{ width: `${b.fillLevel}%` }}></div></div><span className="font-black italic">{b.fillLevel}%</span></div></td><td className="px-6 py-4 font-black text-brand-600 italic">{b.lastCollection ? new Date(b.lastCollection).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'N/A'}</td><td className="px-6 py-4"><span className={`w-1.5 h-1.5 rounded-full inline-block mr-2 ${isHardwareLinked && b.lastHardwareUpdate ? 'bg-emerald-500 shadow-[0_0_5px_#10b981]' : 'bg-slate-300'}`}></span>
<span className="font-black uppercase tracking-widest opacity-40">{isHardwareLinked && b.lastHardwareUpdate ? 'Live' : 'No Signal'}</span></td></tr>))}</tbody></table></div></div></div>)}
          {view === 'analytics' && <div className="h-full bg-brand-50 p-4"><AnalyticsHub bins={bins} reports={reports} currentUser={currentUser} onLocateHardware={(coords) => { setMapCenter(coords); setView('map'); }} /></div>}
        </div>

        {/* Resolution Modal */}
        {resolvingReportId && (
          <div className="fixed inset-0 bg-[#0f172a]/90 backdrop-blur-2xl z-[1000] flex items-center justify-center p-6 animate-fade-in">
             <div className="bg-white rounded-[3rem] p-12 w-full max-w-lg shadow-4xl text-center relative overflow-hidden">
                <h2 className="text-4xl font-black uppercase italic tracking-tighter text-brand-900 mb-6 leading-none">Rectify Hub Alert</h2>
                <div className="space-y-8">
                  <div className="space-y-4 text-left px-4">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-[0.4em] ml-2 italic leading-none">Update Status</label>
                    <div className="grid grid-cols-2 gap-4">
                      <button 
                        onClick={() => setResolutionStatus('in-progress')}
                        className={`py-4 rounded-xl font-black uppercase text-[9px] tracking-widest border-2 transition-all ${resolutionStatus === 'in-progress' ? 'bg-amber-50 border-amber-500 text-amber-600' : 'bg-white border-slate-100 text-slate-400'}`}
                      >
                        In Progress
                      </button>
                      <button 
                        onClick={() => setResolutionStatus('resolved')}
                        className={`py-4 rounded-xl font-black uppercase text-[9px] tracking-widest border-2 transition-all ${resolutionStatus === 'resolved' ? 'bg-emerald-50 border-emerald-500 text-emerald-600' : 'bg-white border-slate-100 text-slate-400'}`}
                      >
                        Resolved
                      </button>
                    </div>
                  </div>
                  <div className="space-y-4 text-left px-4">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-[0.4em] ml-2 italic leading-none">Resolution Intelligence Note</label>
                    <textarea 
                      value={resolutionNote} 
                      onChange={(e) => setResolutionNote(e.target.value)}
                      className="w-full bg-slate-50 border-4 border-slate-100 rounded-[2rem] p-8 text-lg font-black focus:border-emerald-500 outline-none transition-all shadow-inner text-brand-900 italic"
                      placeholder="e.g. Cleared overflow via Unit 104 dispatch..."
                      rows={4}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-6 pt-2">
                    <button onClick={() => setResolvingReportId(null)} className="py-8 bg-slate-50 text-slate-400 rounded-2xl font-black uppercase tracking-[0.3em] text-[10px] italic transition-all hover:bg-slate-100 active:scale-95">Abort</button>
                    <button onClick={handleFinalizeResolution} className={`py-8 ${resolutionStatus === 'resolved' ? 'bg-emerald-600' : 'bg-amber-500'} text-white rounded-2xl font-black uppercase tracking-[0.3em] text-[10px] shadow-2xl italic transition-all active:scale-95`}>
                      Commit {resolutionStatus === 'resolved' ? 'Closeout' : 'Update'}
                    </button>
                  </div>
                </div>
             </div>
          </div>
        )}
        
        {dispatchBin && (
          <div className="fixed inset-0 bg-[#0f172a]/90 backdrop-blur-2xl z-[1000] flex items-center justify-center p-6 animate-fade-in">
             <div className="bg-white rounded-[3rem] p-12 w-full max-w-lg shadow-4xl text-center relative overflow-hidden"><div className="absolute top-10 right-[-20px] opacity-[0.03] text-6xl font-black italic select-none pointer-events-none uppercase">Dispatch</div><h2 className="text-4xl font-black uppercase italic tracking-tighter text-brand-900 mb-2 leading-none">Initialize Unit</h2><p className="text-[10px] font-black text-brand-500 uppercase tracking-[0.2em] italic mb-10">{dispatchBin.id} - {dispatchBin.streetName}</p><div className="space-y-10"><div className="space-y-4 text-left px-4"><label className="text-[9px] font-black text-slate-300 uppercase tracking-[0.5em] ml-2 italic leading-none">Commander Initials</label><input type="text" value={driverName} onChange={(e) => setDriverName(e.target.value)} className="w-full bg-slate-50 border-4 border-slate-100 rounded-[2rem] p-8 text-3xl font-black focus:border-brand-900 outline-none transition-all shadow-inner text-center uppercase tracking-widest text-brand-900" placeholder="RAM" autoFocus /></div><div className="grid grid-cols-2 gap-6 pt-2"><button onClick={() => setDispatchBin(null)} disabled={isDispatching} className="py-8 bg-slate-50 text-slate-400 rounded-2xl font-black uppercase tracking-[0.3em] text-[10px] italic transition-all hover:bg-slate-100 active:scale-95">Abort</button><button onClick={handleStartDispatch} disabled={isDispatching} className="py-8 bg-brand-900 text-white rounded-2xl font-black uppercase tracking-[0.3em] text-[10px] shadow-2xl italic transition-all hover:bg-black active:scale-95 flex items-center justify-center gap-4">{isDispatching ? <i className="fa-solid fa-circle-notch animate-spin text-xl"></i> : 'Confirm Execute'}</button></div></div></div>
          </div>
        )}
      </main>
      {/* Survey Config Modal */}
      {showSurveyConfig && (
        <div className="fixed inset-0 bg-brand-900/90 backdrop-blur-xl z-[10000] flex items-center justify-center p-6 animate-fade-in">
          <div className="bg-white rounded-[3rem] p-12 w-full max-w-xl shadow-4xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-12 opacity-5 text-8xl font-black italic select-none uppercase">Link</div>
            <button onClick={() => setShowSurveyConfig(false)} className="absolute top-8 right-8 text-brand-300 hover:text-brand-900 transition-colors">
              <i className="fa-solid fa-xmark text-2xl"></i>
            </button>
            
            <div className="mb-10">
              <h3 className="text-4xl font-black uppercase italic tracking-tighter text-brand-900 leading-none mb-2">Survey Configuration</h3>
              <p className="text-[10px] font-black text-brand-400 uppercase tracking-widest italic">Global Feedback Node Endpoint</p>
            </div>

            <div className="space-y-8">
              <div className="bg-brand-50 p-6 rounded-[2rem] border border-brand-100 shadow-inner">
                <label className="text-[8px] font-black text-brand-400 uppercase tracking-widest block mb-3 italic">Google Form URL</label>
                <input 
                  type="text" 
                  value={surveyUrl}
                  onChange={(e) => {
                    setSurveyUrl(e.target.value);
                    localStorage.setItem('neuro_survey_url', e.target.value);
                  }}
                  placeholder="Paste Google Form Link..."
                  className="w-full bg-white border border-brand-200 rounded-xl px-4 py-4 text-xs font-mono text-brand-900 focus:border-brand-500 outline-none transition-all shadow-sm"
                />
              </div>

              <div className="bg-brand-900 rounded-[2rem] p-8 text-white shadow-2xl">
                <p className="text-[10px] font-bold leading-relaxed uppercase tracking-tight opacity-80">
                  This link will be embedded in all municipal unit tags. When citizens scan a bin, they will be directed to this form to provide operational feedback.
                </p>
              </div>

              <button 
                onClick={() => setShowSurveyConfig(false)}
                className="w-full py-6 bg-brand-900 text-white rounded-[2rem] font-black uppercase text-xs tracking-[0.2em] italic shadow-xl hover:bg-black transition-all"
              >
                Confirm Operational Link
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
