
import { Bin, BinStatus, Truck } from './types';

export const DISTRICTS = ['Sector Alpha', 'Sector Beta'];

const CENTERS = {
    'Sector Alpha': { lat: 12.9698, lng: 80.1144 },
    'Sector Beta': { lat: 12.9734, lng: 80.1340 }
};

export const INITIAL_BINS: Bin[] = [
  // LoRa Hardware Node 1
  {
    id: `BIN-001`,
    locationName: `Terminal Alpha-1`,
    streetName: `Industrial Corridor A`,
    coordinates: { lat: 12.9698, lng: 80.1144 },
    fillLevel: 0,
    depth: 200,
    sensorReading: 200,
    batteryLevel: 100,
    signalStrength: 0,
    temperature: 0,
    lastCollection: new Date().toISOString(),
    status: BinStatus.OFFLINE,
    district: 'Sector Alpha',
    history: [
      { timestamp: new Date(Date.now() - 86400000).toISOString(), operator: 'Operator 01', fillLevelAtCollection: 85 },
      { timestamp: new Date(Date.now() - 172800000).toISOString(), operator: 'Operator 02', fillLevelAtCollection: 92 }
    ]
  },
  // LoRa Hardware Node 2
  {
    id: `BIN-002`,
    locationName: `Terminal Beta-1`,
    streetName: `Logistic Zone B`,
    coordinates: { lat: 12.9734, lng: 80.1340 },
    fillLevel: 0,
    depth: 200,
    sensorReading: 200,
    batteryLevel: 100,
    signalStrength: 0,
    temperature: 0,
    lastCollection: new Date().toISOString(),
    status: BinStatus.OFFLINE,
    district: 'Sector Beta',
    history: [
      { timestamp: new Date(Date.now() - 43200000).toISOString(), operator: 'Operator 02', fillLevelAtCollection: 78 }
    ]
  }
];

export const INITIAL_FLEET: Truck[] = DISTRICTS.map((d, i) => ({
    id: `UNIT-${100 + i}`,
    driver: ['Operator 01', 'Operator 02'][i],
    coordinates: CENTERS[d as keyof typeof CENTERS],
    status: 'idle',
    capacity: 0,
    district: d
}));
