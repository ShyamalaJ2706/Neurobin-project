
export enum BinStatus {
  NORMAL = 'NORMAL',
  WARNING = 'WARNING',
  CRITICAL = 'CRITICAL',
  OFFLINE = 'OFFLINE'
}

export interface Coordinates {
  lat: number;
  lng: number;
}

export interface CollectionRecord {
  timestamp: string;
  operator: string;
  fillLevelAtCollection?: number; // New: Audit data for load management
}

export interface CitizenReport {
  id: string;
  binId: string;
  userId?: string; // Link to authenticated citizen
  binStreetName?: string;
  type: 'overflow' | 'damage' | 'odor' | 'other';
  message: string;
  timestamp: string;
  status: 'pending' | 'in-progress' | 'resolved';
  source?: 'report' | 'complaint';
  userLocation?: Coordinates;
  locationName?: string;
  rectifiedBy?: string; 
  rectifiedAt?: string;
  resolutionNote?: string;
}

export interface Bin {
  id: string;
  locationName: string;
  streetName: string; 
  coordinates: Coordinates; 
  fillLevel: number;
  depth: number;
  sensorReading: number;
  batteryLevel: number;
  signalStrength: number;
  rssi?: number;
  temperature: number;
  lastCollection: string;
  status: BinStatus;
  district: string;
  lastHardwareUpdate?: string; 
  isGpsLocked?: boolean;
  history?: CollectionRecord[];
}

export interface Truck {
  id: string;
  driver: string;
  coordinates: Coordinates;
  status: 'idle' | 'enroute' | 'collecting';
  capacity: number;
  district: string;
  currentMission?: {
    targetBinId: string;
    targetStreet: string;
    eta: string;
    distance: string;
    progress: number;
  };
}

export interface RouteSuggestion {
  optimizedOrder: string[];
  estimatedDistanceKm: number;
  reasoning: string;
  priorityBins: string[];
}

export interface User {
  username: string;
  password?: string;
  name?: string;
  email?: string;
  role: 'admin' | 'district_manager' | 'citizen';
  assignedDistrict: string | 'ALL';
  registeredAt?: string;
}
